# =============================================================================
# modules/pdf_extractor.py
# Extraction du texte brut depuis les PDF + nettoyage complet.
# =============================================================================

import logging
import re
from pathlib import Path
from typing import Optional

import pdfplumber
from pypdf import PdfReader

logger = logging.getLogger(__name__)


class PDFExtractor:

    def __init__(self, filepath: str, max_pages: Optional[int] = None):
        self.filepath = Path(filepath)
        self.max_pages = max_pages
        self.text = ""
        self.page_count = 0
        self.extraction_method = ""

        if not self.filepath.exists():
            raise FileNotFoundError(f"Fichier introuvable : {self.filepath}")
        if self.filepath.suffix.lower() != ".pdf":
            raise ValueError(f"Extension invalide : {self.filepath.suffix}")

    def extract(self) -> str:
        text = self._extract_with_pdfplumber()
        if not text or len(text.strip()) < 10:
            text = self._extract_with_pypdf()
        self.text = self._clean_text(text)
        return self.text

    def _extract_with_pdfplumber(self) -> str:
        try:
            text_parts = []
            with pdfplumber.open(str(self.filepath)) as pdf:
                self.page_count = len(pdf.pages)
                pages = pdf.pages[:self.max_pages] if self.max_pages else pdf.pages
                for i, page in enumerate(pages):
                    page_text = page.extract_text()
                    if page_text:
                        text_parts.append(page_text)
                    tables = page.extract_tables()
                    for table in tables:
                        if table:
                            text_parts.append(self._table_to_text(table))
            if text_parts:
                self.extraction_method = "pdfplumber"
            return "\n\n".join(text_parts)
        except Exception as error:
            logger.error(f"Erreur pdfplumber sur {self.filepath.name} : {error}")
            return ""

    def _extract_with_pypdf(self) -> str:
        try:
            text_parts = []
            reader = PdfReader(str(self.filepath))
            self.page_count = len(reader.pages)
            pages = reader.pages[:self.max_pages] if self.max_pages else reader.pages
            for page in pages:
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(page_text)
            if text_parts:
                self.extraction_method = "pypdf"
            return "\n\n".join(text_parts)
        except Exception as error:
            logger.error(f"Erreur pypdf sur {self.filepath.name} : {error}")
            return ""

    @staticmethod
    def _table_to_text(table: list) -> str:
        lines = []
        for row in table:
            if row:
                cleaned_row = [str(cell) if cell else "" for cell in row]
                lines.append("\t".join(cleaned_row))
        return "\n".join(lines)

    @staticmethod
    def _clean_text(text: str) -> str:
        """Nettoyage complet du texte extrait."""
        if not text:
            return ""
        # Caracteres de controle
        text = text.replace("\x00", "")
        text = text.replace("\x0b", " ")
        text = text.replace("\x0c", "\n")
        text = text.replace("\xa0", " ")
        # Fins de ligne Windows/Mac
        text = text.replace("\r\n", "\n")
        text = text.replace("\r", "\n")
        # Recollement des mots coupes par un tiret
        text = re.sub(r"-\n([a-z])", r"\1", text)
        # Espaces multiples (pas les newlines)
        text = re.sub(r"[ \t]+", " ", text)
        # Reduire sauts de ligne multiples a 2 max
        text = re.sub(r"\n{3,}", "\n\n", text)
        # Trim chaque ligne
        lines = [l.strip() for l in text.split("\n")]
        return "\n".join(lines).strip()

    def get_metadata(self) -> dict:
        return {
            "filename": self.filepath.name,
            "filepath": str(self.filepath),
            "page_count": self.page_count,
            "text_length": len(self.text),
            "extraction_method": self.extraction_method,
            "success": len(self.text) > 0,
        }
