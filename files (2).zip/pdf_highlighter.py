# =============================================================================
# modules/pdf_highlighter.py
# Surligne les champs trouves dans le PDF avec pdfplumber + pypdf.
# Bug fix : utiliser NameObject/TextStringObject pour les cles/valeurs.
# =============================================================================

import re
import logging
from pathlib import Path

import pdfplumber
from pypdf import PdfReader, PdfWriter
from pypdf.annotations import Highlight
from pypdf.generic import ArrayObject, FloatObject, NameObject, TextStringObject

logger = logging.getLogger(__name__)


def value_to_search_terms(field_name, value):
    if value is None:
        return []
    terms = []
    if field_name == "PST_ISIN":
        terms.append(str(value))
    elif field_name == "BIL":
        return ["BIL"] if value is True else []
    elif field_name == "CAPITAL_PROTECTION":
        v = int(value) if isinstance(value, float) and value == int(value) else value
        terms.extend([f"{v}%", f"{v} %", str(v)])
    elif field_name == "MATURITY":
        s = str(value)
        terms.append(s)
        m = re.search(r"(\d{4})", s)
        if m:
            terms.append(m.group(1))
    elif field_name == "WORST_OR_AVERAGE":
        if value == "W":
            terms.extend(["Worst-of", "worst-of", "worst of", "Worst", "WO"])
        elif value == "A":
            terms.extend(["Average", "average", "averaging"])
    elif field_name == "ISSUER":
        terms.append(str(value))
        parts = str(value).split()
        if len(parts) > 1 and len(parts[0]) > 2:
            terms.append(parts[0])
    elif field_name == "CURRENCY":
        terms.append(str(value))
    return terms


def find_words_on_page(page_words, search_text):
    for w in page_words:
        if search_text.lower() in w["text"].strip().lower() and len(search_text) >= 2:
            return [{"x0": float(w["x0"]), "y0": float(w["top"]),
                     "x1": float(w["x1"]), "y1": float(w["bottom"])}]
    search_parts = search_text.lower().split()
    if len(search_parts) < 2:
        return []
    for i in range(len(page_words) - len(search_parts) + 1):
        match = True
        for j, part in enumerate(search_parts):
            wt = page_words[i + j]["text"].strip().lower()
            if part not in wt and wt not in part:
                match = False
                break
        if match:
            matched = page_words[i:i + len(search_parts)]
            return [{"x0": min(float(w["x0"]) for w in matched),
                     "y0": min(float(w["top"]) for w in matched),
                     "x1": max(float(w["x1"]) for w in matched),
                     "y1": max(float(w["bottom"]) for w in matched)}]
    return []


def highlight_pdf(pdf_path, output_path, extracted_values, field_colors):
    try:
        reader = PdfReader(pdf_path)
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)

        count = 0
        with pdfplumber.open(pdf_path) as pdf:
            for page_num, page in enumerate(pdf.pages):
                ph = page.height
                pw_list = page.extract_words()
                if not pw_list:
                    continue
                for field, value in extracted_values.items():
                    if field in ("CLN",):
                        continue
                    terms = value_to_search_terms(field, value)
                    if not terms:
                        continue
                    color = field_colors.get(field, (0.5, 0.5, 0.5))
                    found = False
                    for term in terms:
                        positions = find_words_on_page(pw_list, term)
                        if not positions:
                            continue
                        for pos in positions:
                            x0 = pos["x0"] - 1
                            x1 = pos["x1"] + 1
                            y0 = ph - pos["y1"] - 1
                            y1 = ph - pos["y0"] + 1
                            hl = Highlight(
                                rect=(x0, y0, x1, y1),
                                quad_points=ArrayObject([
                                    FloatObject(x0), FloatObject(y1),
                                    FloatObject(x1), FloatObject(y1),
                                    FloatObject(x0), FloatObject(y0),
                                    FloatObject(x1), FloatObject(y0),
                                ]),
                            )
                            hl[NameObject("/C")] = ArrayObject([
                                FloatObject(color[0]),
                                FloatObject(color[1]),
                                FloatObject(color[2]),
                            ])
                            hl[NameObject("/T")] = TextStringObject(field)
                            hl[NameObject("/Contents")] = TextStringObject(
                                f"{field}: {value}"
                            )
                            writer.add_annotation(
                                page_number=page_num, annotation=hl
                            )
                            count += 1
                            found = True
                        if found:
                            break
                    if found:
                        break

        if count > 0:
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "wb") as f:
                writer.write(f)
        return count

    except Exception as error:
        logger.error(f"Erreur highlight : {error}")
        return 0
