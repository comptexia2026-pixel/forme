# =============================================================================
# main.py
# Pipeline principal V2 : extraction, export, surlignage, textes convertis.
#
# Usage :
#   python main.py
#   python main.py --input /chemin/pdfs --format all --verbose
# =============================================================================

import argparse
import sys
import time
import logging
from pathlib import Path

import config
from modules.pdf_extractor import PDFExtractor
from modules.field_extractor import FieldExtractor
from modules.data_exporter import DataExporter
from modules.pdf_highlighter import highlight_pdf
from modules.utils import (
    setup_logging, discover_pdf_files, format_summary, save_converted_texts,
)


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Extraction d'informations depuis des term sheets PDF.",
    )
    parser.add_argument("--input", "-i", type=str, default=str(config.INPUT_DIR))
    parser.add_argument("--output", "-o", type=str, default=str(config.OUTPUT_DIR))
    parser.add_argument("--format", "-f", choices=["csv", "excel", "json", "all"],
                        default=config.OUTPUT_FORMAT)
    parser.add_argument("--verbose", "-v", action="store_true")
    parser.add_argument("--no-highlight", action="store_true",
                        help="Desactive le surlignage PDF.")
    parser.add_argument("--max-pages", type=int, default=config.MAX_PAGES)
    return parser.parse_args()


def process_single_pdf(filepath: Path, max_pages=None) -> dict:
    logger = logging.getLogger("termsheet_extractor")

    # Extraction du texte
    pdf_ext = PDFExtractor(str(filepath), max_pages=max_pages)
    text = pdf_ext.extract()

    if not text:
        logger.warning(f"Aucun texte extrait de {filepath.name}")
        return {
            "source_file": filepath.name,
            "text": "",
            "values": {
                "PST_ISIN": None, "BIL": None, "CLN": None,
                "CAPITAL_PROTECTION": None, "MATURITY": None,
                "WORST_OR_AVERAGE": None, "CURRENCY": None, "ISSUER": None,
            },
            "underlying_isins": [],
            "metadata": pdf_ext.get_metadata(),
        }

    # Extraction des champs
    field_ext = FieldExtractor(
        text=text,
        patterns=config.EXTRACTION_PATTERNS,
        bil_keywords=config.BIL_KEYWORDS,
        known_issuers=config.KNOWN_ISSUERS,
        valid_isin_prefixes=config.VALID_ISIN_PREFIXES,
        valid_currencies=config.VALID_CURRENCIES,
        issuer_false_positives=config.ISSUER_FALSE_POSITIVES,
    )
    results = field_ext.extract_all()

    return {
        "source_file": filepath.name,
        "text": text,
        "values": results["values"],
        "underlying_isins": results["underlying_isins"],
        "metadata": pdf_ext.get_metadata(),
    }


def run_pipeline(args):
    start_time = time.time()

    log_level = "DEBUG" if args.verbose else config.LOG_LEVEL
    logger = setup_logging(log_level, config.LOG_FORMAT, str(config.LOG_FILE))

    logger.info("Demarrage du pipeline V2")
    logger.info(f"Repertoire d'entree  : {args.input}")
    logger.info(f"Repertoire de sortie : {args.output}")

    # Decouverte des PDF
    pdf_files = discover_pdf_files(args.input, config.ALLOWED_EXTENSIONS)
    if not pdf_files:
        logger.warning(f"Aucun PDF dans : {args.input}")
        logger.info("Placez vos PDF dans data/input/ et relancez.")
        sys.exit(0)

    logger.info(f"{len(pdf_files)} PDF detecte(s).")

    # Traitement
    records = []
    for i, pdf_file in enumerate(pdf_files, 1):
        logger.info(f"[{i}/{len(pdf_files)}] {pdf_file.name}")
        try:
            record = process_single_pdf(pdf_file, args.max_pages)
            records.append(record)

            v = record["values"]
            logger.info(f"  ISIN={v['PST_ISIN']} | ISSUER={v['ISSUER']} | "
                        f"MAT={v['MATURITY']} | CUR={v['CURRENCY']}")
        except Exception as error:
            logger.error(f"Erreur sur {pdf_file.name} : {error}")

    if not records:
        logger.error("Aucun enregistrement produit.")
        sys.exit(1)

    # Export
    exporter = DataExporter(
        output_dir=args.output,
        filename=config.OUTPUT_FILENAME,
        csv_separator=config.CSV_SEPARATOR,
        csv_encoding=config.CSV_ENCODING,
    )

    if args.format == "csv":
        exporter.export_csv(records)
    elif args.format == "excel":
        exporter.export_excel(records)
    elif args.format == "json":
        exporter.export_json(records)
    elif args.format == "all":
        exporter.export_all(records)

    # Textes convertis
    save_converted_texts(records, str(config.CLEANED_TEXTS_DIR))
    logger.info(f"Textes convertis dans : {config.CLEANED_TEXTS_DIR}")

    # Surlignage
    if not args.no_highlight:
        annotated_dir = Path(args.output) / "annotated"
        for r in records:
            pdf_path = Path(args.input) / r["source_file"]
            if pdf_path.exists():
                out_path = annotated_dir / f"annotated_{r['source_file']}"
                n = highlight_pdf(
                    str(pdf_path), str(out_path),
                    r["values"], config.FIELD_COLORS,
                )
                logger.info(f"  Surlignage {r['source_file']}: {n} annotation(s)")

    # Resume
    summary = format_summary(records)
    print(summary)

    elapsed = time.time() - start_time
    logger.info(f"Pipeline termine en {elapsed:.2f}s.")


if __name__ == "__main__":
    args = parse_arguments()
    run_pipeline(args)
