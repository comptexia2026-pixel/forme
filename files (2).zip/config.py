# =============================================================================
# config.py
# Configuration centrale du projet Term Sheet Extractor V2
# =============================================================================

import os
from pathlib import Path

# -----------------------------------------------------------------------------
# CHEMINS DU PROJET
# -----------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
INPUT_DIR = BASE_DIR / "data" / "input"
OUTPUT_DIR = BASE_DIR / "data" / "output"
RAW_PDF_DIR = BASE_DIR / "data" / "raw_pdf"
CLEANED_TEXTS_DIR = BASE_DIR / "data" / "converted_texts"
LOG_DIR = BASE_DIR / "logs"

for directory in [INPUT_DIR, OUTPUT_DIR, RAW_PDF_DIR, CLEANED_TEXTS_DIR, LOG_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# -----------------------------------------------------------------------------
# PARAMETRES D'EXTRACTION PDF
# -----------------------------------------------------------------------------

ALLOWED_EXTENSIONS = [".pdf"]
MAX_PAGES = None
DEFAULT_ENCODING = "utf-8"

# -----------------------------------------------------------------------------
# PREFIXES ISIN VALIDES (codes pays ISO 3166)
# -----------------------------------------------------------------------------

VALID_ISIN_PREFIXES = [
    "XS", "CH", "DE", "FR", "GB", "US", "LU", "NL", "IT", "AT", "IE",
    "BE", "ES", "JP", "AU", "CA", "NO", "SE", "DK", "FI", "HK", "SG",
]

# -----------------------------------------------------------------------------
# PATTERNS REGEX POUR L'EXTRACTION DES CHAMPS
# -----------------------------------------------------------------------------

EXTRACTION_PATTERNS = {

    "PST_ISIN": [
        r"(?:ISIN\s*(?:code|Code)?\s*[:\-]?\s*)([A-Z]{2}[A-Z0-9]{10})",
        r"(?:Code\s+ISIN\s*[:\-]?\s*)([A-Z]{2}[A-Z0-9]{10})",
        r"\b([A-Z]{2}[A-Z0-9]{10})\b",
    ],

    "CAPITAL_PROTECTION": [
        r"(?i)Capital\s+Protection\s*(?:\(at\s+Expiry\))?\s*[:\-]?\s*(None|\d{1,3}(?:[.,]\d+)?)\s*%?",
        r"(?i)Minimum\s+Redemption\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%",
        r"(?i)Protection\s+du\s+Capital\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%",
        r"(?i)Capital\s+Guarantee\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%",
    ],

    "MATURITY": [
        r"(?i)(?:Maturity\s+Date|Redemption\s+Date\s*/?\s*Maturity\s+Date)\s*[:.]?\s*(\d{1,2}\s+\w+\s+\d{4})",
        r"(?i)Redemption\s+Date\s*/\s*(\d{1,2}\s+\w+\s+\d{4})",
        r"(?i)Maturity\s+Date\s*[:.]?\s*(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4})",
        r"(?i)(?:Date\s+de\s+)?Maturit[ey]\s*[:.]?\s*(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4})",
        r"(?i)Echeance\s*[:.]?\s*(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4})",
        r"(?i)Maturity\s+Date\s*\n\s*(\d{1,2}\s+\w+\s+\d{4})",
    ],

    "WORST_OR_AVERAGE": [
        r"\bWO\b",
        r"(?i)\b(worst[\s\-]?of)\b",
        r"(?i)\b(worst[\s\-]?performing)\b",
        r"(?i)(linked\s+to\s+worst)",
        r"(?i)(lowest\s+performing)",
        r"(?i)\b(average|averaging)\b",
        r"(?i)\b(basket\s+average)\b",
        r"(?i)(performance\s+moyenne)\b",
    ],

    "ISSUER": [
        r"(?:^|\n)\s*Issuer\s*[:.]?\s+([A-Z][A-Za-z\s&',\.\(\)\-]+?)(?:,\s*(?:a\s+bank|incorporated|acting|Zurich|London)|(?:\n))",
        r"(?:^|\n)\s*Issuer\s*:\s*\n\s*([A-Z][A-Z\s&',\.\(\)\-]+?)(?:\n)",
        r"ISSUER\s*:\s*([A-Z][A-Z\s&',\.\(\)\-]+?)(?:\n)",
        r"Issuer\s*/\s*Warrant\s*Issuer\s+([A-Za-z\s&',\.\(\)\-]+?)(?:\n)",
        r"Emetteur\s*:\s*([A-Za-z\s&',\.\(\)\-]+?)(?:\n)",
    ],

    "CURRENCY": [
        r"(?i)(?:Redemption\s+Currency|Specified\s+Currency|Financing\s+Level\s+Currency)\s*[:.]?\s*([A-Z]{3})",
        r"(?i)(?:^|\n)\s*Currency\s*[:.]?\s*([A-Z]{3})",
        r"(?i)Denomination\s*[:.]?\s*([A-Z]{3})",
    ],
}

# -----------------------------------------------------------------------------
# MOTS-CLES POUR LA DETECTION BIL
# -----------------------------------------------------------------------------

BIL_KEYWORDS = [
    "Banque Internationale a Luxembourg",
    "Banque Internationale \u00e0 Luxembourg",
    "www.bil.com",
    "69 Route d'Esch",
    "69, route d'Esch",
    "69 Route d",
    "(BIL)",
]

# -----------------------------------------------------------------------------
# LISTE DES EMETTEURS CONNUS (tries du plus specifique au moins specifique)
# -----------------------------------------------------------------------------

KNOWN_ISSUERS = [
    "NATIXIS STRUCTURED ISSUANCE SA",
    "BNP Paribas Issuance B.V.",
    "BNP PARIBAS ISSUANCE B.V.",
    "Credit Suisse International",
    "UBS AG",
    "BNP Paribas SA",
    "BNP Paribas",
    "NATIXIS",
    "Natixis",
    "Goldman Sachs",
    "Societe Generale",
    "Barclays",
    "Deutsche Bank",
    "HSBC",
    "Leonteq Securities",
    "Julius Baer",
    "Vontobel",
    "Morgan Stanley",
    "J.P. Morgan",
    "Raiffeisen",
    "UniCredit",
    "Nomura",
]

# Devises valides pour le filtrage
VALID_CURRENCIES = [
    "USD", "EUR", "CHF", "GBP", "JPY", "CAD", "AUD",
    "SGD", "HKD", "NOK", "SEK", "DKK", "CNY",
]

# Faux positifs a filtrer dans l'extraction Issuer
ISSUER_FALSE_POSITIVES = [
    "risk", "on the", "an amount", "Exercise",
    "at maturity", "but to", "which", "along",
]

# -----------------------------------------------------------------------------
# PARAMETRES DE SORTIE
# -----------------------------------------------------------------------------

OUTPUT_FORMAT = "all"
OUTPUT_FILENAME = "extraction_results"
CSV_SEPARATOR = ";"
CSV_ENCODING = "utf-8-sig"

# -----------------------------------------------------------------------------
# PARAMETRES DE LOGGING
# -----------------------------------------------------------------------------

LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_FILE = LOG_DIR / "extraction.log"

# -----------------------------------------------------------------------------
# COULEURS POUR LE SURLIGNAGE PDF
# -----------------------------------------------------------------------------

FIELD_COLORS = {
    "PST_ISIN":            (0.2, 0.4, 1.0),
    "ISSUER":              (0.6, 0.2, 0.8),
    "MATURITY":            (0.2, 0.7, 0.3),
    "CAPITAL_PROTECTION":  (1.0, 0.6, 0.0),
    "WORST_OR_AVERAGE":    (0.9, 0.2, 0.2),
    "CURRENCY":            (0.0, 0.6, 0.6),
    "BIL":                 (0.9, 0.8, 0.0),
}
