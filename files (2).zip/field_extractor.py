# =============================================================================
# modules/field_extractor.py
# Extraction des champs metier V2 avec scoring ISIN.
# =============================================================================

import re
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class FieldExtractor:

    def __init__(self, text: str, patterns: dict, bil_keywords: list,
                 known_issuers: list, valid_isin_prefixes: list,
                 valid_currencies: list, issuer_false_positives: list):
        self.text = text
        self.patterns = patterns
        self.bil_keywords = bil_keywords
        self.known_issuers = known_issuers
        self.valid_isin_prefixes = valid_isin_prefixes
        self.valid_currencies = valid_currencies
        self.issuer_false_positives = issuer_false_positives

    def extract_all(self) -> dict:
        # ISINs avec scoring
        all_isins = self._find_real_isins()
        pst_isin, underlying_isins = self._classify_isins(all_isins)

        values = {
            "PST_ISIN": pst_isin,
            "BIL": self._extract_bil(),
            "CLN": self._extract_cln(),
            "CAPITAL_PROTECTION": self._extract_capital_protection(),
            "MATURITY": self._extract_maturity(),
            "WORST_OR_AVERAGE": self._extract_worst_or_average(),
            "CURRENCY": self._extract_currency(),
            "ISSUER": self._extract_issuer(),
        }

        return {"values": values, "underlying_isins": underlying_isins}

    # ----- ISIN avec scoring -----

    def _find_real_isins(self) -> list:
        candidates = re.findall(r"\b([A-Z]{2}[A-Z0-9]{10})\b", self.text)
        real = []
        for c in candidates:
            if c[:2] in self.valid_isin_prefixes and re.search(r"\d", c):
                if c not in real:
                    real.append(c)
        return real

    def _score_isin(self, isin: str) -> int:
        pos = self.text.find(isin)
        if pos == -1:
            return 9999
        score = 9999
        for kw in ["ISIN", "Valor", "Security Number", "ISIN Code",
                    "Code ISIN", "ISIN code", "Security Codes"]:
            for m in re.finditer(re.escape(kw), self.text):
                d = abs(pos - m.start())
                if d < score:
                    score = d
        # Penalite contexte underlying
        ctx = self.text[max(0, pos - 150):pos + len(isin) + 150]
        underlying_kws = ["Bloomberg", "Underlying", "RIC:", "Ticker",
                          "Asset Component", "Share"]
        n_underlying = sum(1 for uk in underlying_kws if uk in ctx)
        if n_underlying >= 2:
            score += 800
        return score

    def _classify_isins(self, all_isins: list) -> tuple:
        if not all_isins:
            return None, []
        if len(all_isins) == 1:
            return all_isins[0], []
        scored = [(isin, self._score_isin(isin)) for isin in all_isins]
        scored.sort(key=lambda x: x[1])
        pst = scored[0][0]
        underlyings = [s[0] for s in scored[1:]]
        return pst, underlyings

    # ----- BIL -----

    def _extract_bil(self) -> bool:
        for kw in self.bil_keywords:
            if kw in self.text:
                return True
        for m in re.finditer(r"\bBIL\b", self.text):
            ctx = self.text[max(0, m.start() - 30):m.end() + 30]
            if not any(fp in ctx for fp in ["BILL", "BILLION", "BILLING"]):
                return True
        return False

    # ----- CLN -----

    def _extract_cln(self) -> bool:
        return bool(re.search(r"(?i)\b(credit[\s\-]?linked\s+note|CLN)\b", self.text))

    # ----- CAPITAL PROTECTION -----

    def _extract_capital_protection(self) -> Optional[float]:
        for p in self.patterns.get("CAPITAL_PROTECTION", []):
            m = re.search(p, self.text)
            if m:
                val = m.group(1)
                if val.lower() == "none":
                    return 0.0
                try:
                    return float(val.replace(",", "."))
                except ValueError:
                    pass
        return None

    # ----- MATURITY -----

    def _extract_maturity(self) -> Optional[str]:
        for p in self.patterns.get("MATURITY", []):
            m = re.search(p, self.text)
            if m:
                return m.group(1).strip()
        # Open End
        if re.search(r"(?i)Expiration\s+Date\s*\(?\s*Expiry\s*\)?\s*[:.]?\s*Open\s+End", self.text):
            return "Open End"
        # Investment Term X years
        m = re.search(r"(?i)Investment\s+Term\s+(?:Up\s+to\s+)?(\d+)\s+years?", self.text)
        if m:
            return f"Up to {m.group(1)} years"
        return None

    # ----- WORST OR AVERAGE -----

    def _extract_worst_or_average(self) -> Optional[str]:
        # WO dans le titre (Natixis)
        if re.search(r"\bWO\b", self.text):
            return "W"
        if re.search(r"(?i)\b(worst[\s\-]?of|worst[\s\-]?performing|linked\s+to\s+worst|lowest\s+performing)", self.text):
            return "W"
        if re.search(r"(?i)\b(average|averaging|basket\s+average|performance\s+moyenne)", self.text):
            return "A"
        return None

    # ----- CURRENCY -----

    def _extract_currency(self) -> Optional[str]:
        for p in self.patterns.get("CURRENCY", []):
            m = re.search(p, self.text)
            if m:
                val = m.group(1)
                if val in self.valid_currencies:
                    return val
        return None

    # ----- ISSUER -----

    def _extract_issuer(self) -> Optional[str]:
        # Strategie 1 : regex
        for p in self.patterns.get("ISSUER", []):
            m = re.search(p, self.text)
            if m:
                val = m.group(1).strip()
                val = re.sub(r"\s+", " ", val).rstrip(" ,;:-")
                if 3 < len(val) < 80:
                    if not any(fp.lower() in val.lower()
                               for fp in self.issuer_false_positives):
                        return val

        # Strategie 2 : noms connus avec proximite au mot "Issuer"
        best = None
        best_pos = len(self.text)
        for k in self.known_issuers:
            pos = self.text.find(k)
            if pos != -1:
                near_issuer = False
                for im in re.finditer(r"(?i)\bIssuer\b", self.text):
                    if abs(pos - im.start()) < 200:
                        near_issuer = True
                        break
                effective_pos = pos - 5000 if near_issuer else pos
                if effective_pos < best_pos:
                    best_pos = effective_pos
                    best = k
        return best
