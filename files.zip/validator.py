# =============================================================================
# modules/validator.py
# Module de validation des donnees extraites.
# Verifie la coherence, la completude et la vraisemblance des champs.
# =============================================================================

import re
import logging
from datetime import datetime
from typing import List

logger = logging.getLogger(__name__)


class DataValidator:
    """
    Classe chargee de valider les resultats de l'extraction.

    La validation s'effectue a deux niveaux :
      1. Validation individuelle : chaque champ est verifie
         independamment (format, plage de valeurs, coherence).
      2. Validation croisee : les champs sont compares entre eux
         pour detecter les incoherences (ex: un produit BIL dont
         l'emetteur n'est pas BIL).

    Attributs :
        required_fields (list) : champs obligatoires.
        min_confidence (float) : score de confiance minimum.
    """

    def __init__(self, required_fields: list, min_confidence: float = 0.5):
        """
        Initialise le validateur.

        Args:
            required_fields: liste des champs qui doivent obligatoirement
                etre presents pour qu'un enregistrement soit valide.
            min_confidence: score de confiance minimum pour accepter
                une valeur extraite.
        """
        self.required_fields = required_fields
        self.min_confidence = min_confidence

    def validate_record(self, record: dict) -> dict:
        """
        Valide un enregistrement complet et genere un rapport.

        Le rapport de validation contient :
          - is_valid (bool) : True si l'enregistrement passe toutes les regles
          - errors (list) : liste des erreurs bloquantes
          - warnings (list) : liste des avertissements non bloquants
          - field_status (dict) : statut de validation par champ

        Args:
            record: dictionnaire avec "values" et "confidence".

        Returns:
            Rapport de validation sous forme de dictionnaire.
        """
        report = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "field_status": {},
        }

        values = record.get("values", {})
        confidence = record.get("confidence", {})

        # --- Validation de chaque champ ---
        self._validate_isin(values, confidence, report)
        self._validate_bil(values, confidence, report)
        self._validate_capital_protection(values, confidence, report)
        self._validate_maturity(values, confidence, report)
        self._validate_worst_or_average(values, confidence, report)
        self._validate_issuer(values, confidence, report)

        # --- Verification des champs obligatoires ---
        for field in self.required_fields:
            if values.get(field) is None:
                report["errors"].append(
                    f"Champ obligatoire manquant : {field}"
                )
                report["is_valid"] = False

        # --- Verification des scores de confiance ---
        for field, score in confidence.items():
            if score < self.min_confidence and values.get(field) is not None:
                report["warnings"].append(
                    f"Confiance faible pour {field} : {score:.2f} "
                    f"(minimum requis : {self.min_confidence})"
                )

        # --- Validations croisees ---
        self._cross_validate(values, report)

        return report

    def validate_batch(self, records: List[dict]) -> dict:
        """
        Valide un lot d'enregistrements et produit un resume global.

        Args:
            records: liste d'enregistrements a valider.

        Returns:
            Dictionnaire contenant :
              - total : nombre total d'enregistrements
              - valid : nombre d'enregistrements valides
              - invalid : nombre d'enregistrements invalides
              - details : liste des rapports individuels
              - summary : resume des erreurs les plus frequentes
        """
        batch_report = {
            "total": len(records),
            "valid": 0,
            "invalid": 0,
            "details": [],
            "error_summary": {},
        }

        for record in records:
            report = self.validate_record(record)
            batch_report["details"].append(report)

            if report["is_valid"]:
                batch_report["valid"] += 1
            else:
                batch_report["invalid"] += 1

            # Comptage des types d'erreurs
            for error in report["errors"]:
                error_type = error.split(":")[0].strip()
                batch_report["error_summary"][error_type] = (
                    batch_report["error_summary"].get(error_type, 0) + 1
                )

        logger.info(
            f"Validation du lot : {batch_report['valid']}/{batch_report['total']} "
            f"enregistrements valides."
        )

        return batch_report

    def _validate_isin(self, values: dict, confidence: dict,
                       report: dict) -> None:
        """
        Valide le code ISIN.

        Regles :
          - Doit comporter exactement 12 caracteres
          - Les 2 premiers caracteres sont des lettres (code pays)
          - Les 10 suivants sont alphanumeriques
        """
        isin = values.get("PST_ISIN")

        if isin is None:
            report["field_status"]["PST_ISIN"] = "MISSING"
            return

        if not re.match(r"^[A-Z]{2}[A-Z0-9]{10}$", isin):
            report["errors"].append(
                f"Format ISIN invalide : '{isin}' "
                f"(attendu : 2 lettres + 10 alphanumeriques)"
            )
            report["field_status"]["PST_ISIN"] = "INVALID"
            report["is_valid"] = False
        else:
            report["field_status"]["PST_ISIN"] = "VALID"

    def _validate_bil(self, values: dict, confidence: dict,
                      report: dict) -> None:
        """
        Valide le champ BIL.

        Regles :
          - Doit etre un booleen (True ou False)
        """
        bil = values.get("BIL")

        if bil is None:
            report["field_status"]["BIL"] = "MISSING"
            report["warnings"].append("Champ BIL non determine.")
            return

        if not isinstance(bil, bool):
            report["errors"].append(
                f"Type BIL invalide : {type(bil).__name__} "
                f"(attendu : bool)"
            )
            report["field_status"]["BIL"] = "INVALID"
        else:
            report["field_status"]["BIL"] = "VALID"

    def _validate_capital_protection(self, values: dict, confidence: dict,
                                     report: dict) -> None:
        """
        Valide le niveau de protection du capital.

        Regles :
          - Doit etre un nombre entre 0 et 100
          - Les valeurs les plus courantes sont 0, 90, 95, 100
        """
        cp = values.get("CAPITAL_PROTECTION")

        if cp is None:
            report["field_status"]["CAPITAL_PROTECTION"] = "MISSING"
            return

        if not isinstance(cp, (int, float)):
            report["errors"].append(
                f"Type CAPITAL_PROTECTION invalide : {type(cp).__name__}"
            )
            report["field_status"]["CAPITAL_PROTECTION"] = "INVALID"
            return

        if cp < 0 or cp > 100:
            report["errors"].append(
                f"CAPITAL_PROTECTION hors plage : {cp}% "
                f"(attendu : 0 a 100)"
            )
            report["field_status"]["CAPITAL_PROTECTION"] = "INVALID"
            report["is_valid"] = False
        else:
            report["field_status"]["CAPITAL_PROTECTION"] = "VALID"

            # Avertissement pour les valeurs inhabituelles
            common_values = [0, 80, 90, 95, 100]
            if cp not in common_values:
                report["warnings"].append(
                    f"CAPITAL_PROTECTION inhabituel : {cp}% "
                    f"(valeurs courantes : {common_values})"
                )

    def _validate_maturity(self, values: dict, confidence: dict,
                           report: dict) -> None:
        """
        Valide la date de maturite.

        Regles :
          - Doit etre au format YYYY-MM-DD
          - Doit etre dans le futur ou dans un passe recent (max 2 ans)
          - Doit etre dans un horizon raisonnable (max 30 ans)
        """
        maturity = values.get("MATURITY")

        if maturity is None:
            report["field_status"]["MATURITY"] = "MISSING"
            return

        try:
            mat_date = datetime.strptime(maturity, "%Y-%m-%d")
        except (ValueError, TypeError):
            report["errors"].append(
                f"Format MATURITY invalide : '{maturity}' "
                f"(attendu : YYYY-MM-DD)"
            )
            report["field_status"]["MATURITY"] = "INVALID"
            report["is_valid"] = False
            return

        now = datetime.now()

        # Verification de l'horizon temporel
        years_diff = (mat_date - now).days / 365.25

        if years_diff < -2:
            report["warnings"].append(
                f"MATURITY dans le passe lointain : {maturity} "
                f"(plus de 2 ans)"
            )
        elif years_diff > 30:
            report["warnings"].append(
                f"MATURITY tres eloignee : {maturity} "
                f"(plus de 30 ans)"
            )

        report["field_status"]["MATURITY"] = "VALID"

    def _validate_worst_or_average(self, values: dict, confidence: dict,
                                   report: dict) -> None:
        """
        Valide le type de payoff.

        Regles :
          - Doit etre "W" ou "A"
        """
        wa = values.get("WORST_OR_AVERAGE")

        if wa is None:
            report["field_status"]["WORST_OR_AVERAGE"] = "MISSING"
            return

        if wa not in ("W", "A"):
            report["errors"].append(
                f"WORST_OR_AVERAGE invalide : '{wa}' "
                f"(attendu : 'W' ou 'A')"
            )
            report["field_status"]["WORST_OR_AVERAGE"] = "INVALID"
        else:
            report["field_status"]["WORST_OR_AVERAGE"] = "VALID"

    def _validate_issuer(self, values: dict, confidence: dict,
                         report: dict) -> None:
        """
        Valide le nom de l'emetteur.

        Regles :
          - Ne doit pas etre vide
          - Doit contenir au moins 2 caracteres
          - Ne doit pas contenir de caracteres suspects
        """
        issuer = values.get("ISSUER")

        if issuer is None:
            report["field_status"]["ISSUER"] = "MISSING"
            return

        if len(issuer) < 2:
            report["errors"].append(
                f"ISSUER trop court : '{issuer}'"
            )
            report["field_status"]["ISSUER"] = "INVALID"
            return

        # Detection de caracteres suspects (chiffres excessifs, symboles)
        digit_ratio = sum(c.isdigit() for c in issuer) / len(issuer)
        if digit_ratio > 0.3:
            report["warnings"].append(
                f"ISSUER contient beaucoup de chiffres : '{issuer}' "
                f"(ratio : {digit_ratio:.1%})"
            )

        report["field_status"]["ISSUER"] = "VALID"

    def _cross_validate(self, values: dict, report: dict) -> None:
        """
        Effectue des validations croisees entre les champs.

        Regles croisees :
          - Si BIL=True, l'emetteur devrait contenir "BIL" ou
            "Banque Internationale a Luxembourg"
          - Si CAPITAL_PROTECTION=100%, le produit est probablement
            de type capital garanti (coherence avec le document)
        """
        bil = values.get("BIL")
        issuer = values.get("ISSUER")

        if bil is True and issuer is not None:
            issuer_lower = issuer.lower()
            bil_indicators = ["bil", "banque internationale"]
            if not any(ind in issuer_lower for ind in bil_indicators):
                report["warnings"].append(
                    f"Incoherence potentielle : BIL=True mais "
                    f"l'emetteur est '{issuer}' (ne contient pas "
                    f"de reference a BIL)"
                )
