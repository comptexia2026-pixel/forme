# =============================================================================
# main.py
# Point d'entree principal du pipeline d'extraction de term sheets.
#
# Ce script orchestre l'ensemble du processus :
#   1. Decouverte des fichiers PDF dans le repertoire d'entree
#   2. Extraction du texte brut de chaque PDF
#   3. Extraction des champs metier depuis le texte
#   4. Validation des donnees extraites
#   5. Export des resultats vers CSV, Excel et/ou JSON
#   6. Affichage d'un resume en console
#
# Usage :
#   python main.py
#   python main.py --input /chemin/vers/les/pdfs
#   python main.py --output /chemin/vers/la/sortie --format excel
# =============================================================================

import argparse
import sys
import time
import logging
from pathlib import Path

# Import de la configuration
import config

# Import des modules du projet
from modules.pdf_extractor import PDFExtractor
from modules.field_extractor import FieldExtractor
from modules.data_exporter import DataExporter
from modules.validator import DataValidator
from modules.utils import (
    setup_logging,
    discover_pdf_files,
    format_summary,
    print_record_preview,
)


def parse_arguments():
    """
    Analyse les arguments de la ligne de commande.

    Arguments disponibles :
      --input   : repertoire contenant les PDF (defaut: config.INPUT_DIR)
      --output  : repertoire de sortie (defaut: config.OUTPUT_DIR)
      --format  : format de sortie (csv, excel, json, all)
      --verbose : active le mode debug (affiche plus de details)
      --dry-run : simule l'execution sans ecrire de fichier

    Returns:
        Namespace contenant les arguments parses.
    """
    parser = argparse.ArgumentParser(
        description="Extraction d'informations depuis des term sheets PDF.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exemples d'utilisation :\n"
            "  python main.py\n"
            "  python main.py --input ./mes_pdf --format excel\n"
            "  python main.py --verbose --dry-run\n"
        ),
    )

    parser.add_argument(
        "--input", "-i",
        type=str,
        default=str(config.INPUT_DIR),
        help="Repertoire contenant les fichiers PDF a traiter.",
    )

    parser.add_argument(
        "--output", "-o",
        type=str,
        default=str(config.OUTPUT_DIR),
        help="Repertoire de sortie pour les resultats.",
    )

    parser.add_argument(
        "--format", "-f",
        type=str,
        choices=["csv", "excel", "json", "all"],
        default=config.OUTPUT_FORMAT,
        help="Format de sortie des resultats.",
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Active le mode verbeux (niveau DEBUG).",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simule l'execution sans ecrire de fichier de sortie.",
    )

    parser.add_argument(
        "--max-pages",
        type=int,
        default=config.MAX_PAGES,
        help="Nombre maximum de pages a extraire par PDF.",
    )

    return parser.parse_args()


def process_single_pdf(filepath: Path, max_pages: int = None) -> dict:
    """
    Traite un seul fichier PDF : extraction du texte puis des champs.

    Cette fonction encapsule le traitement complet d'un document :
      1. Extraction du texte brut via PDFExtractor
      2. Extraction des champs metier via FieldExtractor
      3. Ajout des metadonnees d'extraction

    Args:
        filepath: chemin vers le fichier PDF.
        max_pages: nombre max de pages a analyser.

    Returns:
        Dictionnaire contenant :
          - source_file : nom du fichier PDF
          - values : dictionnaire des valeurs extraites
          - confidence : dictionnaire des scores de confiance
          - metadata : informations sur l'extraction
    """
    logger = logging.getLogger("termsheet_extractor")

    # Etape 1 : extraction du texte
    pdf_extractor = PDFExtractor(str(filepath), max_pages=max_pages)
    text = pdf_extractor.extract()

    if not text:
        logger.warning(
            f"Aucun texte extrait de {filepath.name}. "
            f"Le fichier sera ignore."
        )
        return {
            "source_file": filepath.name,
            "values": {
                "PST_ISIN": None,
                "BIL": None,
                "CAPITAL_PROTECTION": None,
                "MATURITY": None,
                "WORST_OR_AVERAGE": None,
                "ISSUER": None,
            },
            "confidence": {
                "PST_ISIN": 0.0,
                "BIL": 0.0,
                "CAPITAL_PROTECTION": 0.0,
                "MATURITY": 0.0,
                "WORST_OR_AVERAGE": 0.0,
                "ISSUER": 0.0,
            },
            "metadata": pdf_extractor.get_metadata(),
        }

    # Etape 2 : extraction des champs metier
    field_extractor = FieldExtractor(
        text=text,
        patterns=config.EXTRACTION_PATTERNS,
        bil_keywords=config.BIL_KEYWORDS,
        known_issuers=config.KNOWN_ISSUERS,
    )

    extraction_results = field_extractor.extract_all()

    # Construction du resultat final
    record = {
        "source_file": filepath.name,
        "values": extraction_results["values"],
        "confidence": extraction_results["confidence"],
        "metadata": pdf_extractor.get_metadata(),
    }

    return record


def run_pipeline(args):
    """
    Execute le pipeline complet d'extraction.

    Le pipeline suit les etapes suivantes :
      1. Configuration du logging
      2. Decouverte des fichiers PDF
      3. Traitement de chaque PDF
      4. Validation des resultats
      5. Export des donnees
      6. Affichage du resume

    Args:
        args: arguments de la ligne de commande (Namespace).
    """
    start_time = time.time()

    # --- Etape 1 : Configuration du logging ---
    log_level = "DEBUG" if args.verbose else config.LOG_LEVEL
    logger = setup_logging(
        log_level=log_level,
        log_format=config.LOG_FORMAT,
        log_file=str(config.LOG_FILE),
    )

    logger.info("Demarrage du pipeline d'extraction de term sheets.")
    logger.info(f"Repertoire d'entree  : {args.input}")
    logger.info(f"Repertoire de sortie : {args.output}")
    logger.info(f"Format de sortie     : {args.format}")

    # --- Etape 2 : Decouverte des fichiers PDF ---
    try:
        pdf_files = discover_pdf_files(
            args.input, config.ALLOWED_EXTENSIONS
        )
    except FileNotFoundError as error:
        logger.error(str(error))
        sys.exit(1)

    if not pdf_files:
        logger.warning(
            f"Aucun fichier PDF trouve dans : {args.input}"
        )
        logger.info(
            "Placez vos fichiers PDF dans le repertoire d'entree "
            "et relancez le script."
        )
        sys.exit(0)

    logger.info(f"{len(pdf_files)} fichier(s) PDF detecte(s).")

    # --- Etape 3 : Traitement de chaque PDF ---
    records = []

    for i, pdf_file in enumerate(pdf_files, start=1):
        logger.info(
            f"Traitement [{i}/{len(pdf_files)}] : {pdf_file.name}"
        )

        try:
            record = process_single_pdf(pdf_file, args.max_pages)
            records.append(record)

            # Apercu du resultat en mode verbose
            if args.verbose:
                preview = print_record_preview(record)
                logger.debug(f"Apercu :\n{preview}")

        except Exception as error:
            logger.error(
                f"Erreur lors du traitement de {pdf_file.name} : {error}",
                exc_info=args.verbose,
            )

    if not records:
        logger.error("Aucun enregistrement produit. Arret du pipeline.")
        sys.exit(1)

    # --- Etape 4 : Validation des resultats ---
    validator = DataValidator(
        required_fields=config.REQUIRED_FIELDS,
        min_confidence=config.MIN_CONFIDENCE_SCORE,
    )

    validation_report = validator.validate_batch(records)

    # --- Etape 5 : Export des donnees ---
    if not args.dry_run:
        exporter = DataExporter(
            output_dir=args.output,
            filename=config.OUTPUT_FILENAME,
            csv_separator=config.CSV_SEPARATOR,
            csv_encoding=config.CSV_ENCODING,
        )

        if args.format == "csv":
            output_path = exporter.export_csv(records)
            logger.info(f"Fichier CSV genere : {output_path}")
        elif args.format == "excel":
            output_path = exporter.export_excel(records)
            logger.info(f"Fichier Excel genere : {output_path}")
        elif args.format == "json":
            output_path = exporter.export_json(records)
            logger.info(f"Fichier JSON genere : {output_path}")
        elif args.format == "all":
            paths = exporter.export_all(records)
            for fmt, path in paths.items():
                logger.info(f"Fichier {fmt.upper()} genere : {path}")
    else:
        logger.info("Mode dry-run : aucun fichier de sortie genere.")

    # --- Etape 6 : Affichage du resume ---
    summary = format_summary(records, validation_report)
    print(summary)

    elapsed = time.time() - start_time
    logger.info(f"Pipeline termine en {elapsed:.2f} secondes.")


# =============================================================================
# POINT D'ENTREE
# =============================================================================

if __name__ == "__main__":
    args = parse_arguments()
    run_pipeline(args)
