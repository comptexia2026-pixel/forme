# =============================================================================
# modules/pdf_extractor.py
# Module responsable de l'extraction du texte brut depuis les fichiers PDF.
# Utilise pdfplumber comme moteur principal et pypdf comme fallback.
# =============================================================================

import logging
from pathlib import Path
from typing import Optional

import pdfplumber
from pypdf import PdfReader

logger = logging.getLogger(__name__)


class PDFExtractor:
    """
    Classe chargee d'extraire le texte brut d'un fichier PDF.

    Deux strategies d'extraction sont implementees :
      1. pdfplumber (prioritaire) : meilleure gestion de la mise en page
         et des tableaux. Convient bien aux term sheets qui contiennent
         souvent des tableaux et des champs cle-valeur.
      2. pypdf (fallback) : utilise si pdfplumber echoue ou retourne
         un texte vide. Moins precis mais plus tolerant aux PDF mal formes.

    Attributs :
        filepath (Path) : chemin vers le fichier PDF a traiter.
        max_pages (int ou None) : nombre max de pages a lire.
        text (str) : texte extrait apres appel a extract().
        page_count (int) : nombre total de pages dans le PDF.
        extraction_method (str) : methode ayant reussi l'extraction.
    """

    def __init__(self, filepath: str, max_pages: Optional[int] = None):
        """
        Initialise l'extracteur avec le chemin du fichier PDF.

        Args:
            filepath: chemin absolu ou relatif vers le fichier PDF.
            max_pages: si defini, limite le nombre de pages extraites.

        Raises:
            FileNotFoundError: si le fichier n'existe pas.
            ValueError: si le fichier n'a pas l'extension .pdf.
        """
        self.filepath = Path(filepath)
        self.max_pages = max_pages
        self.text = ""
        self.page_count = 0
        self.extraction_method = ""

        # Verification de l'existence du fichier
        if not self.filepath.exists():
            raise FileNotFoundError(
                f"Le fichier PDF est introuvable : {self.filepath}"
            )

        # Verification de l'extension
        if self.filepath.suffix.lower() != ".pdf":
            raise ValueError(
                f"Extension invalide : {self.filepath.suffix}. "
                f"Seuls les fichiers .pdf sont acceptes."
            )

    def extract(self) -> str:
        """
        Methode principale d'extraction. Tente pdfplumber d'abord,
        puis pypdf en cas d'echec.

        Returns:
            Le texte extrait du PDF, ou une chaine vide si l'extraction
            echoue completement.
        """
        logger.info(f"Debut de l'extraction du fichier : {self.filepath.name}")

        # Tentative 1 : pdfplumber
        text = self._extract_with_pdfplumber()

        # Tentative 2 : pypdf si pdfplumber a echoue
        if not text or len(text.strip()) < 10:
            logger.warning(
                "pdfplumber n'a pas retourne de texte exploitable. "
                "Basculement vers pypdf."
            )
            text = self._extract_with_pypdf()

        # Nettoyage du texte extrait
        self.text = self._clean_text(text)

        if self.text:
            logger.info(
                f"Extraction reussie ({self.extraction_method}) : "
                f"{len(self.text)} caracteres, {self.page_count} page(s)."
            )
        else:
            logger.error(
                f"Echec total de l'extraction pour : {self.filepath.name}"
            )

        return self.text

    def _extract_with_pdfplumber(self) -> str:
        """
        Extraction du texte via pdfplumber.

        pdfplumber est particulierement efficace pour les documents
        contenant des tableaux et des champs alignes en colonnes,
        ce qui est le cas des term sheets.

        Returns:
            Texte extrait ou chaine vide en cas d'erreur.
        """
        try:
            text_parts = []

            with pdfplumber.open(str(self.filepath)) as pdf:
                self.page_count = len(pdf.pages)
                pages_to_process = pdf.pages

                # Limitation du nombre de pages si demande
                if self.max_pages is not None:
                    pages_to_process = pdf.pages[:self.max_pages]

                for i, page in enumerate(pages_to_process):
                    page_text = page.extract_text()

                    if page_text:
                        text_parts.append(page_text)
                    else:
                        logger.debug(
                            f"Page {i + 1} : aucun texte extrait par pdfplumber."
                        )

                    # Extraction des tableaux de la page
                    tables = page.extract_tables()
                    for table in tables:
                        if table:
                            table_text = self._table_to_text(table)
                            text_parts.append(table_text)

            if text_parts:
                self.extraction_method = "pdfplumber"

            return "\n\n".join(text_parts)

        except Exception as error:
            logger.error(
                f"Erreur pdfplumber sur {self.filepath.name} : {error}"
            )
            return ""

    def _extract_with_pypdf(self) -> str:
        """
        Extraction du texte via pypdf (methode de secours).

        pypdf est moins precis que pdfplumber pour les mises en page
        complexes, mais il est plus robuste face aux PDF corrompus
        ou non standards.

        Returns:
            Texte extrait ou chaine vide en cas d'erreur.
        """
        try:
            text_parts = []
            reader = PdfReader(str(self.filepath))
            self.page_count = len(reader.pages)

            pages_to_process = reader.pages
            if self.max_pages is not None:
                pages_to_process = reader.pages[:self.max_pages]

            for i, page in enumerate(pages_to_process):
                page_text = page.extract_text()

                if page_text:
                    text_parts.append(page_text)
                else:
                    logger.debug(
                        f"Page {i + 1} : aucun texte extrait par pypdf."
                    )

            if text_parts:
                self.extraction_method = "pypdf"

            return "\n\n".join(text_parts)

        except Exception as error:
            logger.error(
                f"Erreur pypdf sur {self.filepath.name} : {error}"
            )
            return ""

    @staticmethod
    def _table_to_text(table: list) -> str:
        """
        Convertit un tableau extrait par pdfplumber en texte lisible.

        Chaque ligne du tableau est jointe avec des tabulations.
        Cela permet aux patterns regex de retrouver les paires
        cle-valeur qui sont souvent dans des cellules adjacentes.

        Args:
            table: liste de listes representant les lignes du tableau.

        Returns:
            Representation textuelle du tableau.
        """
        lines = []
        for row in table:
            if row:
                # Remplacement des cellules vides par une chaine vide
                cleaned_row = [str(cell) if cell else "" for cell in row]
                lines.append("\t".join(cleaned_row))
        return "\n".join(lines)

    @staticmethod
    def _clean_text(text: str) -> str:
        """
        Nettoie le texte brut extrait du PDF.

        Operations effectuees :
          - Suppression des caracteres de controle inutiles
          - Normalisation des espaces multiples
          - Suppression des lignes totalement vides consecutives

        Args:
            text: texte brut a nettoyer.

        Returns:
            Texte nettoye.
        """
        if not text:
            return ""

        # Suppression des caracteres nuls et de controle
        text = text.replace("\x00", "")

        # Normalisation des espaces multiples en un seul espace
        import re
        text = re.sub(r"[ \t]+", " ", text)

        # Reduction des sauts de ligne multiples a deux maximum
        text = re.sub(r"\n{3,}", "\n\n", text)

        # Suppression des espaces en debut et fin
        text = text.strip()

        return text

    def get_metadata(self) -> dict:
        """
        Retourne les metadonnees d'extraction sous forme de dictionnaire.

        Returns:
            Dictionnaire contenant les informations sur l'extraction.
        """
        return {
            "filename": self.filepath.name,
            "filepath": str(self.filepath),
            "page_count": self.page_count,
            "text_length": len(self.text),
            "extraction_method": self.extraction_method,
            "success": len(self.text) > 0,
        }
