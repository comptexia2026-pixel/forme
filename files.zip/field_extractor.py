# =============================================================================
# modules/field_extractor.py
# Module responsable de l'extraction des champs metier depuis le texte brut.
# Utilise des expressions regulieres et des heuristiques metier pour
# identifier chaque champ defini dans le cahier des charges.
# =============================================================================

import re
import logging
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)


class FieldExtractor:
    """
    Classe chargee d'extraire les champs metier d'une term sheet
    a partir du texte brut extrait du PDF.

    Les champs extraits sont :
      - PST_ISIN        : code ISIN du produit structure
      - BIL             : booleen indiquant si c'est un produit BIL
      - CAPITAL_PROTECTION : niveau de protection du capital (en %)
      - MATURITY        : date de maturite du produit
      - WORST_OR_AVERAGE : type de payoff ("W" ou "A")
      - ISSUER          : banque emettrice du produit

    Chaque methode d'extraction retourne la valeur trouvee et un score
    de confiance entre 0.0 et 1.0 pour permettre une validation ulterieure.

    Attributs :
        text (str) : texte brut du PDF dans lequel chercher.
        patterns (dict) : dictionnaire des patterns regex par champ.
        bil_keywords (list) : mots-cles pour la detection BIL.
        known_issuers (list) : liste des emetteurs connus.
    """

    def __init__(self, text: str, patterns: dict, bil_keywords: list,
                 known_issuers: list):
        """
        Initialise l'extracteur de champs.

        Args:
            text: texte brut extrait du PDF.
            patterns: dictionnaire des patterns regex (depuis config.py).
            bil_keywords: liste de mots-cles pour detecter les produits BIL.
            known_issuers: liste des noms d'emetteurs connus.
        """
        self.text = text
        self.patterns = patterns
        self.bil_keywords = bil_keywords
        self.known_issuers = known_issuers

    def extract_all(self) -> dict:
        """
        Lance l'extraction de tous les champs.

        Cette methode orchestre l'appel a chaque extracteur specialise
        et retourne un dictionnaire contenant toutes les valeurs extraites,
        ainsi que les scores de confiance associes.

        Returns:
            Dictionnaire avec deux sous-dictionnaires :
              - "values" : les valeurs extraites pour chaque champ
              - "confidence" : les scores de confiance pour chaque champ
        """
        results = {
            "values": {},
            "confidence": {},
        }

        # Extraction de chaque champ avec sa methode dediee
        extractors = {
            "PST_ISIN": self._extract_isin,
            "BIL": self._extract_bil,
            "CAPITAL_PROTECTION": self._extract_capital_protection,
            "MATURITY": self._extract_maturity,
            "WORST_OR_AVERAGE": self._extract_worst_or_average,
            "ISSUER": self._extract_issuer,
        }

        for field_name, extractor_func in extractors.items():
            value, confidence = extractor_func()
            results["values"][field_name] = value
            results["confidence"][field_name] = confidence

            log_msg = (
                f"Champ {field_name} : "
                f"valeur='{value}', confiance={confidence:.2f}"
            )
            if confidence >= 0.7:
                logger.info(log_msg)
            elif confidence >= 0.4:
                logger.warning(log_msg)
            else:
                logger.warning(f"Champ {field_name} : non trouve ou faible confiance.")

        return results

    def _extract_isin(self) -> tuple:
        """
        Extrait le code ISIN du produit structure.

        Le code ISIN suit le format international ISO 6166 :
          - 2 lettres (code pays)
          - 10 caracteres alphanumeriques

        La confiance depend du pattern qui a matche :
          - 1.0 si le mot-cle "ISIN" precede le code
          - 0.6 si le code est detecte seul par son format

        Returns:
            Tuple (valeur, confiance).
        """
        isin_patterns = self.patterns.get("PST_ISIN", [])

        for i, pattern in enumerate(isin_patterns):
            match = re.search(pattern, self.text)
            if match:
                isin_code = match.group(1)

                # Validation de la longueur (doit etre exactement 12 chars)
                if len(isin_code) != 12:
                    continue

                # Score de confiance decroissant selon le pattern
                # Le premier pattern est le plus specifique (avec label "ISIN")
                if i == 0:
                    confidence = 1.0
                elif i == 1:
                    confidence = 0.9
                else:
                    # Dernier pattern : detection par format seul
                    confidence = 0.6

                logger.debug(
                    f"ISIN detecte avec le pattern {i} : {isin_code}"
                )
                return isin_code, confidence

        return None, 0.0

    def _extract_bil(self) -> tuple:
        """
        Determine si le produit est un produit BIL.

        La detection se fait par recherche de mots-cles specifiques
        dans le texte. La presence d'un mot-cle BIL dans un contexte
        pertinent (nom de l'emetteur, description du produit) donne
        une confiance elevee.

        Returns:
            Tuple (booleen, confiance).
        """
        text_upper = self.text.upper()

        for keyword in self.bil_keywords:
            if keyword.upper() in text_upper:
                # Verification du contexte : le mot-cle ne doit pas
                # etre un faux positif (par exemple "BILL" ou "BILLING")
                keyword_pos = text_upper.find(keyword.upper())
                context_start = max(0, keyword_pos - 50)
                context_end = min(len(text_upper), keyword_pos + len(keyword) + 50)
                context = self.text[context_start:context_end]

                # Exclusion des faux positifs courants
                false_positives = ["BILLING", "BILLBOARD", "BILLION"]
                is_false_positive = False
                for fp in false_positives:
                    if fp in text_upper[keyword_pos:keyword_pos + len(fp) + 2]:
                        is_false_positive = True
                        break

                if not is_false_positive:
                    logger.debug(
                        f"Mot-cle BIL trouve dans le contexte : "
                        f"...{context.strip()}..."
                    )
                    return True, 0.95

        return False, 0.8  # Confiance 0.8 pour "non BIL" car absence de preuve

    def _extract_capital_protection(self) -> tuple:
        """
        Extrait le niveau de protection du capital.

        La valeur attendue est un pourcentage :
          - 100% signifie capital entierement protege
          - 0% signifie aucune protection
          - Les valeurs intermediaires (ex: 90%) sont possibles

        Le resultat est normalise en pourcentage (float).

        Returns:
            Tuple (pourcentage en float ou None, confiance).
        """
        cp_patterns = self.patterns.get("CAPITAL_PROTECTION", [])

        for i, pattern in enumerate(cp_patterns):
            match = re.search(pattern, self.text)
            if match:
                raw_value = match.group(1)

                # Normalisation : remplacement de la virgule par un point
                raw_value = raw_value.replace(",", ".")

                try:
                    value = float(raw_value)
                except ValueError:
                    continue

                # Validation : le pourcentage doit etre entre 0 et 100
                if 0 <= value <= 100:
                    confidence = 0.95 if i < 2 else 0.7
                    logger.debug(
                        f"Capital protection detecte : {value}% "
                        f"(pattern {i})"
                    )
                    return value, confidence

        # Heuristique de secours : recherche de "capital protected"
        # ou "capital garanti" sans pourcentage explicite
        fallback_patterns = [
            r"(?i)\b(capital\s+protected|capital\s+garanti)\b",
            r"(?i)\b(full\s+capital\s+protection)\b",
            r"(?i)\b(protection\s+totale\s+du\s+capital)\b",
        ]

        for pattern in fallback_patterns:
            if re.search(pattern, self.text):
                logger.debug(
                    "Capital protection detecte par heuristique (100% suppose)"
                )
                return 100.0, 0.6

        return None, 0.0

    def _extract_maturity(self) -> tuple:
        """
        Extrait la date de maturite du produit.

        Plusieurs formats de date sont supportes :
          - DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY
          - DD Month YYYY (ex: 15 January 2025)
          - MM/DD/YYYY (format americain, detecte par heuristique)

        La date est normalisee au format ISO : YYYY-MM-DD.

        Returns:
            Tuple (date au format YYYY-MM-DD ou None, confiance).
        """
        mat_patterns = self.patterns.get("MATURITY", [])

        for i, pattern in enumerate(mat_patterns):
            match = re.search(pattern, self.text)
            if match:
                raw_date = match.group(1)
                normalized = self._normalize_date(raw_date)

                if normalized:
                    confidence = 0.95 if i < 3 else 0.75
                    logger.debug(
                        f"Date de maturite detectee : {raw_date} -> "
                        f"{normalized} (pattern {i})"
                    )
                    return normalized, confidence

        return None, 0.0

    def _normalize_date(self, raw_date: str) -> Optional[str]:
        """
        Normalise une date brute en format ISO YYYY-MM-DD.

        Tente plusieurs formats de parsing pour couvrir les differentes
        conventions de notation rencontrees dans les term sheets.

        Args:
            raw_date: chaine de caracteres representant une date.

        Returns:
            Date normalisee au format YYYY-MM-DD, ou None si le parsing
            echoue pour tous les formats.
        """
        # Liste des formats de date a essayer, dans l'ordre de priorite
        date_formats = [
            "%d/%m/%Y",
            "%d-%m-%Y",
            "%d.%m.%Y",
            "%d/%m/%y",
            "%d-%m-%y",
            "%d.%m.%y",
            "%d %B %Y",      # 15 January 2025
            "%d %b %Y",      # 15 Jan 2025
            "%B %d, %Y",     # January 15, 2025
            "%b %d, %Y",     # Jan 15, 2025
            "%Y-%m-%d",       # Format ISO deja normalise
            "%m/%d/%Y",       # Format americain (en dernier)
        ]

        for fmt in date_formats:
            try:
                parsed = datetime.strptime(raw_date.strip(), fmt)
                return parsed.strftime("%Y-%m-%d")
            except ValueError:
                continue

        logger.debug(f"Impossible de parser la date : '{raw_date}'")
        return None

    def _extract_worst_or_average(self) -> tuple:
        """
        Determine le type de payoff du produit.

        Deux types sont possibles :
          - "W" (Worst-of) : le rendement depend du sous-jacent le moins
            performant du panier.
          - "A" (Average) : le rendement depend de la performance moyenne
            de tous les sous-jacents.

        La detection se fait par mots-cles contextuels.

        Returns:
            Tuple ("W", "A", ou None, confiance).
        """
        wa_patterns = self.patterns.get("WORST_OR_AVERAGE", [])

        for i, pattern in enumerate(wa_patterns):
            match = re.search(pattern, self.text)
            if match:
                matched_text = match.group(1).lower()

                # Classification basee sur le texte matche
                worst_indicators = [
                    "worst", "moins performant", "plus mauvais"
                ]
                average_indicators = [
                    "average", "averaging", "moyenne", "panier moyen"
                ]

                for indicator in worst_indicators:
                    if indicator in matched_text:
                        logger.debug(
                            f"Type Worst-of detecte via : '{matched_text}'"
                        )
                        return "W", 0.9

                for indicator in average_indicators:
                    if indicator in matched_text:
                        logger.debug(
                            f"Type Average detecte via : '{matched_text}'"
                        )
                        return "A", 0.9

        return None, 0.0

    def _extract_issuer(self) -> tuple:
        """
        Extrait le nom de l'emetteur du produit structure.

        La strategie est en deux etapes :
          1. Recherche par patterns regex (champ "Issuer" explicite)
          2. Fallback : recherche des noms d'emetteurs connus dans le texte

        Le nom est nettoye (suppression des espaces superflus, des
        retours a la ligne) avant d'etre retourne.

        Returns:
            Tuple (nom de l'emetteur ou None, confiance).
        """
        # Etape 1 : recherche par patterns regex
        issuer_patterns = self.patterns.get("ISSUER", [])

        for i, pattern in enumerate(issuer_patterns):
            match = re.search(pattern, self.text)
            if match:
                raw_issuer = match.group(1).strip()
                cleaned = self._clean_issuer_name(raw_issuer)

                if cleaned and len(cleaned) > 2:
                    logger.debug(
                        f"Emetteur detecte par regex : '{cleaned}' "
                        f"(pattern {i})"
                    )
                    return cleaned, 0.9

        # Etape 2 : recherche des emetteurs connus dans le texte
        for issuer in self.known_issuers:
            if issuer.lower() in self.text.lower():
                logger.debug(
                    f"Emetteur detecte par correspondance directe : "
                    f"'{issuer}'"
                )
                return issuer, 0.75

        return None, 0.0

    @staticmethod
    def _clean_issuer_name(raw_name: str) -> str:
        """
        Nettoie le nom brut de l'emetteur extrait par regex.

        Operations :
          - Suppression des sauts de ligne et tabulations
          - Reduction des espaces multiples
          - Suppression des caracteres de ponctuation en fin de chaine
          - Limitation de la longueur (les noms trop longs sont suspects)

        Args:
            raw_name: nom brut de l'emetteur.

        Returns:
            Nom nettoye.
        """
        # Suppression des retours a la ligne et tabulations
        name = raw_name.replace("\n", " ").replace("\t", " ")

        # Reduction des espaces multiples
        name = re.sub(r"\s+", " ", name).strip()

        # Suppression de la ponctuation finale
        name = re.sub(r"[,;:\-\s]+$", "", name)

        # Limitation a 80 caracteres (securite contre les extractions erronees)
        if len(name) > 80:
            name = name[:80].rsplit(" ", 1)[0]

        return name
