# =============================================================================
# config.py
# Configuration centrale du projet Term Sheet Extractor
# Ce fichier regroupe tous les parametres modifiables du pipeline.
# =============================================================================

import os
from pathlib import Path

# -----------------------------------------------------------------------------
# CHEMINS DU PROJET
# -----------------------------------------------------------------------------

# Repertoire racine du projet (detecte automatiquement)
BASE_DIR = Path(__file__).resolve().parent

# Repertoire contenant les PDF a traiter
INPUT_DIR = BASE_DIR / "data" / "input"

# Repertoire de sortie pour les resultats (CSV, Excel, JSON)
OUTPUT_DIR = BASE_DIR / "data" / "output"

# Repertoire des logs
LOG_DIR = BASE_DIR / "logs"

# Creation automatique des repertoires s'ils n'existent pas
for directory in [INPUT_DIR, OUTPUT_DIR, LOG_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# -----------------------------------------------------------------------------
# PARAMETRES D'EXTRACTION PDF
# -----------------------------------------------------------------------------

# Extensions de fichiers acceptees
ALLOWED_EXTENSIONS = [".pdf"]

# Nombre maximum de pages a analyser par PDF (None = toutes les pages)
MAX_PAGES = None

# Encodage par defaut pour la lecture du texte
DEFAULT_ENCODING = "utf-8"

# -----------------------------------------------------------------------------
# PATTERNS REGEX POUR L'EXTRACTION DES CHAMPS
# Les patterns sont organises par champ a extraire.
# Chaque champ possede une liste de patterns ordonnes par priorite.
# Le premier pattern qui matche est utilise.
# -----------------------------------------------------------------------------

EXTRACTION_PATTERNS = {

    # Code ISIN : format standard 2 lettres + 10 caracteres alphanumeriques
    "PST_ISIN": [
        r"(?:ISIN\s*(?:code|Code)?\s*[:\-]?\s*)([A-Z]{2}[A-Z0-9]{10})",
        r"(?:Code\s+ISIN\s*[:\-]?\s*)([A-Z]{2}[A-Z0-9]{10})",
        r"\b([A-Z]{2}[A-Z0-9]{10})\b",
    ],

    # Protection du capital : pourcentage entre 0% et 100%
    "CAPITAL_PROTECTION": [
        r"(?:[Cc]apital\s+[Pp]rotection\s*[:\-]?\s*)(\d{1,3}(?:[.,]\d+)?)\s*%",
        r"(?:[Pp]rotection\s+(?:du\s+)?[Cc]apital\s*[:\-]?\s*)(\d{1,3}(?:[.,]\d+)?)\s*%",
        r"(?:[Cc]apital\s+[Gg]uarant(?:ee|y|ie)\s*[:\-]?\s*)(\d{1,3}(?:[.,]\d+)?)\s*%",
        r"(?:[Pp]rotection\s*[:\-]?\s*)(\d{1,3}(?:[.,]\d+)?)\s*%\s*(?:of\s+)?(?:capital|nominal|notional)",
    ],

    # Date de maturite : plusieurs formats de date acceptes
    "MATURITY": [
        r"(?:[Mm]aturity\s+[Dd]ate\s*[:\-]?\s*)(\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4})",
        r"(?:[Dd]ate\s+(?:de\s+)?[Mm]aturit[ey]\s*[:\-]?\s*)(\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4})",
        r"(?:[Ff]inal\s+[Rr]edemption\s+[Dd]ate\s*[:\-]?\s*)(\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4})",
        r"(?:[Mm]aturity\s*[:\-]?\s*)(\d{1,2}\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{4})",
        r"(?:[Ee]cheance\s*[:\-]?\s*)(\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4})",
    ],

    # Worst-of ou Average : detection du type de payoff
    "WORST_OR_AVERAGE": [
        r"(?i)\b(worst[\s\-]?of)\b",
        r"(?i)\b(average|averaging)\b",
        r"(?i)\b(basket\s+average)\b",
        r"(?i)\b(worst\s+performing)\b",
        r"(?i)\b(moins\s+performant|plus\s+mauvais)\b",
        r"(?i)\b(moyenne|panier\s+moyen)\b",
    ],

    # Emetteur / Issuer : noms de banques connues
    "ISSUER": [
        r"(?:[Ii]ssuer\s*[:\-]?\s*)([A-Z][A-Za-z\s&'.]+(?:SA|AG|PLC|NV|Inc|Ltd|GmbH|S\.A\.|N\.V\.)?)",
        r"(?:[Ee]metteur\s*[:\-]?\s*)([A-Z][A-Za-z\s&'.]+(?:SA|AG|PLC|NV|Inc|Ltd|GmbH|S\.A\.|N\.V\.)?)",
        r"(?:[Ii]ssued\s+by\s*[:\-]?\s*)([A-Z][A-Za-z\s&'.]+(?:SA|AG|PLC|NV|Inc|Ltd|GmbH|S\.A\.|N\.V\.)?)",
        r"(?:[Ee]mis\s+par\s*[:\-]?\s*)([A-Z][A-Za-z\s&'.]+(?:SA|AG|PLC|NV|Inc|Ltd|GmbH|S\.A\.|N\.V\.)?)",
    ],
}

# -----------------------------------------------------------------------------
# MOTS-CLES POUR LA DETECTION BIL
# Si l'un de ces mots-cles est present dans le texte, BIL = True
# -----------------------------------------------------------------------------

BIL_KEYWORDS = [
    "Banque Internationale a Luxembourg",
    "Banque Internationale à Luxembourg",
    "BIL ",
    "BIL,",
    "BIL.",
    "BIL-",
    "(BIL)",
]

# -----------------------------------------------------------------------------
# LISTE DES EMETTEURS CONNUS (pour validation et fallback)
# -----------------------------------------------------------------------------

KNOWN_ISSUERS = [
    "BNP Paribas",
    "Societe Generale",
    "Goldman Sachs",
    "Morgan Stanley",
    "J.P. Morgan",
    "JP Morgan",
    "Barclays",
    "Credit Suisse",
    "UBS",
    "Deutsche Bank",
    "HSBC",
    "Citigroup",
    "Natixis",
    "Leonteq",
    "Vontobel",
    "Julius Baer",
    "EFG International",
    "Raiffeisen",
    "Zurcher Kantonalbank",
    "Banque Internationale a Luxembourg",
    "BIL",
    "UniCredit",
    "Intesa Sanpaolo",
    "Nomura",
    "Bank of America",
    "Royal Bank of Canada",
]

# -----------------------------------------------------------------------------
# PARAMETRES DE SORTIE
# -----------------------------------------------------------------------------

# Format de sortie par defaut
OUTPUT_FORMAT = "csv"  # Valeurs possibles : "csv", "excel", "json", "all"

# Nom du fichier de sortie (sans extension)
OUTPUT_FILENAME = "extracted_termsheets"

# Separateur CSV
CSV_SEPARATOR = ";"

# Encodage du fichier CSV
CSV_ENCODING = "utf-8-sig"  # utf-8-sig pour compatibilite Excel

# -----------------------------------------------------------------------------
# PARAMETRES DE LOGGING
# -----------------------------------------------------------------------------

LOG_LEVEL = "INFO"  # Valeurs : DEBUG, INFO, WARNING, ERROR, CRITICAL
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_FILE = LOG_DIR / "extraction.log"

# -----------------------------------------------------------------------------
# PARAMETRES DE VALIDATION
# -----------------------------------------------------------------------------

# Champs obligatoires (une alerte est levee si ces champs sont manquants)
REQUIRED_FIELDS = ["PST_ISIN", "ISSUER", "MATURITY"]

# Score de confiance minimum pour accepter une extraction (0.0 a 1.0)
MIN_CONFIDENCE_SCORE = 0.5
