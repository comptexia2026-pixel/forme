# =============================================================================
# tests/test_field_extractor.py
# Tests unitaires pour le module d'extraction des champs.
# Permet de verifier le bon fonctionnement des patterns regex
# et des heuristiques metier sans avoir besoin de PDF reels.
# =============================================================================

import sys
from pathlib import Path

# Ajout du repertoire parent au path pour les imports
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.field_extractor import FieldExtractor
from config import EXTRACTION_PATTERNS, BIL_KEYWORDS, KNOWN_ISSUERS


def create_extractor(text: str) -> FieldExtractor:
    """
    Fonction utilitaire pour creer un FieldExtractor avec la
    configuration standard du projet.
    """
    return FieldExtractor(
        text=text,
        patterns=EXTRACTION_PATTERNS,
        bil_keywords=BIL_KEYWORDS,
        known_issuers=KNOWN_ISSUERS,
    )


def test_extract_isin_with_label():
    """Test : extraction ISIN avec le label explicite."""
    text = "ISIN Code: XS1234567890\nIssuer: Test Bank"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["PST_ISIN"] == "XS1234567890"
    assert results["confidence"]["PST_ISIN"] >= 0.9
    print("[OK] test_extract_isin_with_label")


def test_extract_isin_standalone():
    """Test : extraction ISIN par format seul (sans label)."""
    text = "Le produit XS9876543210 arrive a echeance en 2025."
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["PST_ISIN"] == "XS9876543210"
    assert results["confidence"]["PST_ISIN"] >= 0.5
    print("[OK] test_extract_isin_standalone")


def test_extract_bil_positive():
    """Test : detection BIL positive."""
    text = "Emetteur : Banque Internationale a Luxembourg (BIL)"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["BIL"] is True
    assert results["confidence"]["BIL"] >= 0.9
    print("[OK] test_extract_bil_positive")


def test_extract_bil_negative():
    """Test : detection BIL negative (pas de mot-cle BIL)."""
    text = "Emetteur : Goldman Sachs International"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["BIL"] is False
    print("[OK] test_extract_bil_negative")


def test_extract_bil_false_positive():
    """Test : le mot BILLING ne doit pas declencher BIL=True."""
    text = "BILLING address: 123 Main Street"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["BIL"] is False
    print("[OK] test_extract_bil_false_positive")


def test_extract_capital_protection_100():
    """Test : protection du capital a 100%."""
    text = "Capital Protection: 100%\nMaturity Date: 15/06/2026"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["CAPITAL_PROTECTION"] == 100.0
    assert results["confidence"]["CAPITAL_PROTECTION"] >= 0.9
    print("[OK] test_extract_capital_protection_100")


def test_extract_capital_protection_zero():
    """Test : pas de protection du capital (0%)."""
    text = "Capital Protection: 0%\nRisk level: High"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["CAPITAL_PROTECTION"] == 0.0
    print("[OK] test_extract_capital_protection_zero")


def test_extract_maturity_european_format():
    """Test : date de maturite au format europeen DD/MM/YYYY."""
    text = "Maturity Date: 15/06/2026\nISSuer: BNP Paribas"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["MATURITY"] == "2026-06-15"
    print("[OK] test_extract_maturity_european_format")


def test_extract_maturity_text_format():
    """Test : date de maturite au format textuel."""
    text = "Maturity: 15 January 2027\nProtection: 100%"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["MATURITY"] == "2027-01-15"
    print("[OK] test_extract_maturity_text_format")


def test_extract_worst_of():
    """Test : detection du type Worst-of."""
    text = "Payoff type: Worst-of basket\nBarrier: 60%"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["WORST_OR_AVERAGE"] == "W"
    print("[OK] test_extract_worst_of")


def test_extract_average():
    """Test : detection du type Average."""
    text = "The coupon is linked to the average performance."
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["WORST_OR_AVERAGE"] == "A"
    print("[OK] test_extract_average")


def test_extract_issuer_with_label():
    """Test : extraction de l'emetteur avec label explicite."""
    text = "Issuer: BNP Paribas SA\nISIN: FR1234567890"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert "BNP Paribas" in results["values"]["ISSUER"]
    print("[OK] test_extract_issuer_with_label")


def test_extract_issuer_by_known_name():
    """Test : detection de l'emetteur par nom connu (fallback)."""
    text = "Product distributed via Goldman Sachs network. Barrier: 60%"
    extractor = create_extractor(text)
    results = extractor.extract_all()
    assert results["values"]["ISSUER"] == "Goldman Sachs"
    print("[OK] test_extract_issuer_by_known_name")


def test_full_extraction():
    """Test : extraction complete d'un texte simulant une term sheet."""
    text = """
    TERM SHEET - STRUCTURED PRODUCT

    ISIN Code: XS0987654321
    Issuer: Societe Generale SA
    Issue Date: 01/03/2024
    Maturity Date: 01/03/2029
    Capital Protection: 90%

    The product is linked to a basket of 3 equities.
    The payoff is based on the worst-of performance
    of the underlying basket.

    Distributed by Banque Internationale a Luxembourg (BIL).
    """

    extractor = create_extractor(text)
    results = extractor.extract_all()

    values = results["values"]
    assert values["PST_ISIN"] == "XS0987654321"
    assert values["BIL"] is True
    assert values["CAPITAL_PROTECTION"] == 90.0
    assert values["MATURITY"] == "2029-03-01"
    assert values["WORST_OR_AVERAGE"] == "W"
    assert "Societe Generale" in values["ISSUER"]

    print("[OK] test_full_extraction")


def test_empty_text():
    """Test : extraction sur un texte vide."""
    extractor = create_extractor("")
    results = extractor.extract_all()
    assert results["values"]["PST_ISIN"] is None
    assert results["values"]["MATURITY"] is None
    print("[OK] test_empty_text")


# =============================================================================
# EXECUTION DES TESTS
# =============================================================================

if __name__ == "__main__":
    print("Execution des tests unitaires")
    print("=" * 50)

    tests = [
        test_extract_isin_with_label,
        test_extract_isin_standalone,
        test_extract_bil_positive,
        test_extract_bil_negative,
        test_extract_bil_false_positive,
        test_extract_capital_protection_100,
        test_extract_capital_protection_zero,
        test_extract_maturity_european_format,
        test_extract_maturity_text_format,
        test_extract_worst_of,
        test_extract_average,
        test_extract_issuer_with_label,
        test_extract_issuer_by_known_name,
        test_full_extraction,
        test_empty_text,
    ]

    passed = 0
    failed = 0

    for test_func in tests:
        try:
            test_func()
            passed += 1
        except AssertionError as error:
            print(f"[ECHEC] {test_func.__name__} : {error}")
            failed += 1
        except Exception as error:
            print(f"[ERREUR] {test_func.__name__} : {error}")
            failed += 1

    print("=" * 50)
    print(f"Resultats : {passed} reussi(s), {failed} echoue(s)")
