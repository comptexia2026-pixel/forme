# =============================================================================
# modules/utils.py
# Fonctions utilitaires partagees entre les modules du projet.
# Configuration du logging, fonctions de formatage, helpers divers.
# =============================================================================

import logging
import sys
from pathlib import Path
from typing import List


def setup_logging(log_level: str = "INFO", log_format: str = None,
                  log_file: str = None) -> logging.Logger:
    """
    Configure le systeme de logging pour l'ensemble du projet.

    Le logging est configure avec deux handlers :
      1. Console (stdout) : affiche les messages INFO et superieur
      2. Fichier (optionnel) : enregistre tous les messages DEBUG et superieur

    Cela permet d'avoir un suivi detaille dans le fichier log tout en
    gardant un affichage propre dans le terminal.

    Args:
        log_level: niveau de log minimum (DEBUG, INFO, WARNING, ERROR).
        log_format: format des messages de log. Si None, un format par
            defaut est utilise.
        log_file: chemin du fichier de log. Si None, seul le handler
            console est configure.

    Returns:
        Le logger racine configure.
    """
    if log_format is None:
        log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # Creation du logger racine du projet
    logger = logging.getLogger("termsheet_extractor")
    logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # Suppression des handlers existants (evite les doublons)
    logger.handlers.clear()

    # Handler console
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter(log_format))
    logger.addHandler(console_handler)

    # Handler fichier (si un chemin est fourni)
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(
            str(log_path), encoding="utf-8"
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(logging.Formatter(log_format))
        logger.addHandler(file_handler)

    return logger


def discover_pdf_files(input_dir: str,
                       allowed_extensions: list = None) -> List[Path]:
    """
    Recherche tous les fichiers PDF dans un repertoire donne.

    La recherche est non recursive par defaut (ne descend pas dans
    les sous-repertoires). Seuls les fichiers avec les extensions
    autorisees sont retenus.

    Args:
        input_dir: chemin du repertoire a scanner.
        allowed_extensions: liste des extensions acceptees.
            Par defaut : [".pdf"]

    Returns:
        Liste triee des chemins vers les fichiers PDF trouves.

    Raises:
        FileNotFoundError: si le repertoire n'existe pas.
    """
    if allowed_extensions is None:
        allowed_extensions = [".pdf"]

    dir_path = Path(input_dir)

    if not dir_path.exists():
        raise FileNotFoundError(
            f"Le repertoire d'entree n'existe pas : {dir_path}"
        )

    if not dir_path.is_dir():
        raise NotADirectoryError(
            f"Le chemin specifie n'est pas un repertoire : {dir_path}"
        )

    pdf_files = []
    for filepath in sorted(dir_path.iterdir()):
        if filepath.is_file() and filepath.suffix.lower() in allowed_extensions:
            pdf_files.append(filepath)

    return pdf_files


def format_summary(records: List[dict], validation_report: dict = None) -> str:
    """
    Genere un resume textuel des resultats d'extraction.

    Ce resume est affiche dans le terminal a la fin du pipeline.
    Il presente les statistiques globales et les eventuels problemes
    detectes.

    Args:
        records: liste des enregistrements extraits.
        validation_report: rapport de validation du lot (optionnel).

    Returns:
        Chaine de caracteres formatee pour l'affichage en console.
    """
    separator = "=" * 60
    lines = [
        "",
        separator,
        "  RESUME DE L'EXTRACTION",
        separator,
        "",
        f"  Documents traites     : {len(records)}",
    ]

    if validation_report:
        lines.extend([
            f"  Enregistrements valides   : {validation_report['valid']}",
            f"  Enregistrements invalides : {validation_report['invalid']}",
        ])

    # Statistiques par champ
    lines.append("")
    lines.append("  Taux de remplissage par champ :")
    lines.append("  " + "-" * 40)

    fields = ["PST_ISIN", "BIL", "CAPITAL_PROTECTION",
              "MATURITY", "WORST_OR_AVERAGE", "ISSUER"]

    for field in fields:
        filled = sum(
            1 for r in records
            if r.get("values", {}).get(field) is not None
        )
        rate = (filled / len(records) * 100) if records else 0
        bar_length = int(rate / 5)
        bar = "#" * bar_length + "." * (20 - bar_length)
        lines.append(
            f"    {field:<22s} [{bar}] {rate:5.1f}%"
        )

    # Erreurs les plus frequentes
    if validation_report and validation_report.get("error_summary"):
        lines.append("")
        lines.append("  Erreurs les plus frequentes :")
        lines.append("  " + "-" * 40)
        for error_type, count in sorted(
            validation_report["error_summary"].items(),
            key=lambda x: x[1], reverse=True
        ):
            lines.append(f"    {error_type} : {count} occurrence(s)")

    lines.append("")
    lines.append(separator)

    return "\n".join(lines)


def print_record_preview(record: dict, max_value_length: int = 50) -> str:
    """
    Genere un apercu formate d'un enregistrement pour le debug.

    Args:
        record: enregistrement a afficher.
        max_value_length: longueur maximale d'une valeur avant troncature.

    Returns:
        Chaine formatee representant l'enregistrement.
    """
    lines = []
    source = record.get("source_file", "inconnu")
    lines.append(f"  Fichier : {source}")
    lines.append("  " + "-" * 40)

    values = record.get("values", {})
    confidence = record.get("confidence", {})

    for field, value in values.items():
        conf = confidence.get(field, 0.0)

        # Troncature des valeurs longues
        str_value = str(value) if value is not None else "(vide)"
        if len(str_value) > max_value_length:
            str_value = str_value[:max_value_length] + "..."

        # Indicateur de confiance textuel
        if conf >= 0.7:
            conf_indicator = "[OK]"
        elif conf >= 0.4:
            conf_indicator = "[??]"
        else:
            conf_indicator = "[!!]"

        lines.append(
            f"    {conf_indicator} {field:<22s} : {str_value}"
        )

    return "\n".join(lines)
