# =============================================================================
# modules/data_exporter.py
# Module responsable de l'export des resultats d'extraction vers
# differents formats : CSV, Excel (XLSX) et JSON.
# =============================================================================

import csv
import json
import logging
from pathlib import Path
from typing import List

logger = logging.getLogger(__name__)


class DataExporter:
    """
    Classe chargee d'exporter les resultats d'extraction vers
    des fichiers exploitables.

    Trois formats de sortie sont supportes :
      - CSV  : format tabulaire simple, compatible avec tous les outils.
      - Excel : format XLSX avec mise en forme, necessitant openpyxl.
      - JSON  : format structure, ideal pour l'integration avec d'autres
                systemes ou APIs.

    Attributs :
        output_dir (Path) : repertoire de sortie.
        filename (str) : nom du fichier de sortie (sans extension).
        csv_separator (str) : caractere separateur pour le CSV.
        csv_encoding (str) : encodage du fichier CSV.
    """

    # Colonnes de sortie dans l'ordre souhaite
    COLUMNS = [
        "source_file",
        "PST_ISIN",
        "BIL",
        "CAPITAL_PROTECTION",
        "MATURITY",
        "WORST_OR_AVERAGE",
        "ISSUER",
    ]

    # Colonnes de confiance correspondantes
    CONFIDENCE_COLUMNS = [
        "conf_PST_ISIN",
        "conf_BIL",
        "conf_CAPITAL_PROTECTION",
        "conf_MATURITY",
        "conf_WORST_OR_AVERAGE",
        "conf_ISSUER",
    ]

    def __init__(self, output_dir: str, filename: str = "extracted_termsheets",
                 csv_separator: str = ";", csv_encoding: str = "utf-8-sig"):
        """
        Initialise l'exporteur de donnees.

        Args:
            output_dir: repertoire ou enregistrer les fichiers de sortie.
            filename: nom du fichier de sortie (sans extension).
            csv_separator: separateur de champs pour le CSV.
            csv_encoding: encodage du fichier CSV.
        """
        self.output_dir = Path(output_dir)
        self.filename = filename
        self.csv_separator = csv_separator
        self.csv_encoding = csv_encoding

        # Creation du repertoire de sortie si necessaire
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export_csv(self, records: List[dict]) -> Path:
        """
        Exporte les resultats au format CSV.

        Le CSV inclut :
          - Une ligne d'en-tete avec les noms des colonnes
          - Une ligne par document traite
          - Les valeurs extraites et les scores de confiance

        Le separateur par defaut est le point-virgule (;) pour une
        meilleure compatibilite avec Excel en Europe (ou la virgule
        est le separateur decimal).

        Args:
            records: liste de dictionnaires, un par document traite.
                Chaque dictionnaire contient "values" et "confidence".

        Returns:
            Chemin du fichier CSV cree.
        """
        output_path = self.output_dir / f"{self.filename}.csv"

        all_columns = self.COLUMNS + self.CONFIDENCE_COLUMNS

        try:
            with open(output_path, "w", newline="",
                       encoding=self.csv_encoding) as csvfile:
                writer = csv.DictWriter(
                    csvfile,
                    fieldnames=all_columns,
                    delimiter=self.csv_separator,
                    extrasaction="ignore",
                )
                writer.writeheader()

                for record in records:
                    row = self._flatten_record(record)
                    writer.writerow(row)

            logger.info(
                f"Export CSV reussi : {output_path} "
                f"({len(records)} enregistrement(s))"
            )
            return output_path

        except Exception as error:
            logger.error(f"Erreur lors de l'export CSV : {error}")
            raise

    def export_excel(self, records: List[dict]) -> Path:
        """
        Exporte les resultats au format Excel (XLSX).

        Le fichier Excel inclut :
          - Une feuille "Resultats" avec les valeurs extraites
          - Une feuille "Confiance" avec les scores de confiance
          - Une mise en forme conditionnelle sur les scores de confiance
            (vert = confiance haute, rouge = confiance basse)

        Necessite la bibliotheque openpyxl.

        Args:
            records: liste de dictionnaires, un par document traite.

        Returns:
            Chemin du fichier Excel cree.
        """
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        except ImportError:
            logger.error(
                "openpyxl n'est pas installe. "
                "Installez-le avec : pip install openpyxl"
            )
            raise

        output_path = self.output_dir / f"{self.filename}.xlsx"

        wb = Workbook()

        # --- Feuille 1 : Resultats ---
        ws_results = wb.active
        ws_results.title = "Resultats"

        # Style de l'en-tete
        header_font = Font(bold=True, color="FFFFFF", size=11)
        header_fill = PatternFill(
            start_color="2F5496", end_color="2F5496", fill_type="solid"
        )
        header_alignment = Alignment(horizontal="center", vertical="center")
        thin_border = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin"),
        )

        # Ecriture de l'en-tete
        for col_idx, col_name in enumerate(self.COLUMNS, start=1):
            cell = ws_results.cell(row=1, column=col_idx, value=col_name)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
            cell.border = thin_border

        # Ecriture des donnees
        for row_idx, record in enumerate(records, start=2):
            flat = self._flatten_record(record)
            for col_idx, col_name in enumerate(self.COLUMNS, start=1):
                value = flat.get(col_name, "")
                cell = ws_results.cell(row=row_idx, column=col_idx, value=value)
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="left")

        # Ajustement de la largeur des colonnes
        for col_idx, col_name in enumerate(self.COLUMNS, start=1):
            max_length = len(col_name)
            for row in ws_results.iter_rows(
                min_row=2, max_row=len(records) + 1,
                min_col=col_idx, max_col=col_idx
            ):
                for cell in row:
                    if cell.value:
                        max_length = max(max_length, len(str(cell.value)))
            ws_results.column_dimensions[
                chr(64 + col_idx)
            ].width = min(max_length + 4, 40)

        # --- Feuille 2 : Confiance ---
        ws_confidence = wb.create_sheet("Confiance")

        conf_columns = ["source_file"] + self.CONFIDENCE_COLUMNS
        for col_idx, col_name in enumerate(conf_columns, start=1):
            cell = ws_confidence.cell(row=1, column=col_idx, value=col_name)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment

        # Couleurs pour les scores de confiance
        green_fill = PatternFill(
            start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"
        )
        yellow_fill = PatternFill(
            start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"
        )
        red_fill = PatternFill(
            start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"
        )

        for row_idx, record in enumerate(records, start=2):
            flat = self._flatten_record(record)

            # Nom du fichier source
            ws_confidence.cell(
                row=row_idx, column=1,
                value=flat.get("source_file", "")
            )

            # Scores de confiance avec mise en forme conditionnelle
            for col_idx, col_name in enumerate(self.CONFIDENCE_COLUMNS, start=2):
                value = flat.get(col_name, 0.0)
                cell = ws_confidence.cell(
                    row=row_idx, column=col_idx, value=value
                )

                # Application de la couleur selon le score
                if isinstance(value, (int, float)):
                    if value >= 0.7:
                        cell.fill = green_fill
                    elif value >= 0.4:
                        cell.fill = yellow_fill
                    else:
                        cell.fill = red_fill

        try:
            wb.save(output_path)
            logger.info(
                f"Export Excel reussi : {output_path} "
                f"({len(records)} enregistrement(s))"
            )
            return output_path
        except Exception as error:
            logger.error(f"Erreur lors de l'export Excel : {error}")
            raise

    def export_json(self, records: List[dict]) -> Path:
        """
        Exporte les resultats au format JSON.

        Le JSON est structure de la maniere suivante :
        {
            "metadata": {
                "total_documents": N,
                "export_date": "YYYY-MM-DD HH:MM:SS"
            },
            "results": [
                {
                    "source_file": "...",
                    "values": { ... },
                    "confidence": { ... }
                },
                ...
            ]
        }

        Args:
            records: liste de dictionnaires, un par document traite.

        Returns:
            Chemin du fichier JSON cree.
        """
        output_path = self.output_dir / f"{self.filename}.json"

        from datetime import datetime

        export_data = {
            "metadata": {
                "total_documents": len(records),
                "export_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "fields": list(self.COLUMNS[1:]),  # Exclusion de source_file
            },
            "results": records,
        }

        try:
            with open(output_path, "w", encoding="utf-8") as jsonfile:
                json.dump(export_data, jsonfile, indent=2, ensure_ascii=False,
                          default=str)

            logger.info(
                f"Export JSON reussi : {output_path} "
                f"({len(records)} enregistrement(s))"
            )
            return output_path

        except Exception as error:
            logger.error(f"Erreur lors de l'export JSON : {error}")
            raise

    def export_all(self, records: List[dict]) -> dict:
        """
        Exporte les resultats dans tous les formats supportes.

        Args:
            records: liste de dictionnaires, un par document traite.

        Returns:
            Dictionnaire avec les chemins des fichiers generes.
        """
        paths = {}

        paths["csv"] = self.export_csv(records)
        paths["json"] = self.export_json(records)

        try:
            paths["excel"] = self.export_excel(records)
        except ImportError:
            logger.warning(
                "Export Excel ignore (openpyxl non disponible)."
            )

        return paths

    @staticmethod
    def _flatten_record(record: dict) -> dict:
        """
        Aplatit un enregistrement structure en un dictionnaire plat
        compatible avec l'ecriture CSV et Excel.

        L'entree a la structure :
        {
            "source_file": "fichier.pdf",
            "values": {"PST_ISIN": "XS123...", ...},
            "confidence": {"PST_ISIN": 0.95, ...}
        }

        La sortie a la structure :
        {
            "source_file": "fichier.pdf",
            "PST_ISIN": "XS123...",
            "conf_PST_ISIN": 0.95,
            ...
        }

        Args:
            record: enregistrement structure.

        Returns:
            Dictionnaire aplati.
        """
        flat = {"source_file": record.get("source_file", "")}

        values = record.get("values", {})
        confidence = record.get("confidence", {})

        for field in ["PST_ISIN", "BIL", "CAPITAL_PROTECTION",
                       "MATURITY", "WORST_OR_AVERAGE", "ISSUER"]:
            flat[field] = values.get(field, "")
            flat[f"conf_{field}"] = confidence.get(field, 0.0)

        return flat
