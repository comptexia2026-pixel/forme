# =============================================================================
# pipeline_v2.py
# Pipeline V2 complet : extraction des term sheets avec tous les correctifs.
# Teste sur les 5 PDF reels fournis.
# =============================================================================

import pdfplumber
import re
import json
import csv
import os
from pathlib import Path
from datetime import datetime

# =============================================================================
# 1. EXTRACTION TEXTE + NETTOYAGE
# =============================================================================

def extract_text(pdf_path):
    """Extrait le texte brut page par page avec pdfplumber."""
    pages_text = []
    with pdfplumber.open(str(pdf_path)) as pdf:
        for page in pdf.pages:
            t = page.extract_text()
            if t:
                pages_text.append(t)
    return "\n\n".join(pages_text)


def clean_text(raw):
    """Nettoie le texte en preservant les espaces entre les mots."""
    if not raw:
        return ""
    text = raw
    text = text.replace("\x00", "")
    text = text.replace("\x0b", " ")
    text = text.replace("\x0c", "\n")
    text = text.replace("\xa0", " ")
    text = text.replace("\r\n", "\n")
    text = text.replace("\r", "\n")
    # Recoller mots coupes par tiret en fin de ligne
    text = re.sub(r"-\n([a-z])", r"\1", text)
    # Espaces multiples (PAS les newlines)
    text = re.sub(r"[ \t]+", " ", text)
    # Reduire les sauts de ligne multiples a 2 max
    text = re.sub(r"\n{3,}", "\n\n", text)
    # Trim chaque ligne
    lines = [l.strip() for l in text.split("\n")]
    return "\n".join(lines).strip()


# =============================================================================
# 2. EXTRACTION DES ISINS AVEC SCORING
# =============================================================================

VALID_ISIN_PREFIXES = [
    "XS", "CH", "DE", "FR", "GB", "US", "LU", "NL", "IT", "AT", "IE",
    "BE", "ES", "JP", "AU", "CA", "NO", "SE", "DK", "FI", "HK", "SG",
]

def find_real_isins(text):
    """Trouve tous les vrais codes ISIN dans le texte."""
    candidates = re.findall(r"\b([A-Z]{2}[A-Z0-9]{10})\b", text)
    real = []
    for c in candidates:
        if c[:2] in VALID_ISIN_PREFIXES and re.search(r"\d", c):
            if c not in real:
                real.append(c)
    return real


def score_isin(text, isin):
    """Score un ISIN : plus bas = plus probable d'etre le PST_ISIN."""
    pos = text.find(isin)
    if pos == -1:
        return 9999

    score = 9999

    # Distance au mot-cle ISIN le plus proche
    for kw in ["ISIN", "Valor", "Security Number", "ISIN Code",
                "Code ISIN", "ISIN code", "Security Codes"]:
        for m in re.finditer(re.escape(kw), text):
            d = abs(pos - m.start())
            if d < score:
                score = d

    # Penalite si dans un contexte underlying
    context = text[max(0, pos - 150):pos + len(isin) + 150]
    underlying_kws = ["Bloomberg", "Underlying", "RIC:", "Ticker",
                       "Asset Component", "ISIN Code", "Share"]
    # Compter combien de mots-cles underlying sont dans le contexte
    n_underlying = sum(1 for uk in underlying_kws if uk in context)
    if n_underlying >= 2:
        score += 800

    return score


def classify_isins(text, all_isins):
    """Separe le PST_ISIN des UNDERLYING_ISINs."""
    if not all_isins:
        return None, []
    if len(all_isins) == 1:
        return all_isins[0], []

    scored = [(isin, score_isin(text, isin)) for isin in all_isins]
    scored.sort(key=lambda x: x[1])

    pst = scored[0][0]
    underlyings = [s[0] for s in scored[1:]]
    return pst, underlyings


# =============================================================================
# 3. EXTRACTION DES CHAMPS
# =============================================================================

def extract_issuer(text):
    """Extrait l'emetteur avec plusieurs strategies."""
    # Strategie 1 : label "Issuer" suivi du nom dans la section General Information
    patterns = [
        # "Issuer UBS AG, Zurich..." ou "Issuer: NATIXIS..."
        r"(?:^|\n)\s*Issuer\s*[:.]?\s+([A-Z][A-Za-z\s&',\.\(\)\-]+?)(?:,\s*(?:a\s+bank|incorporated|acting|Zurich|London)|(?:\n))",
        # "Issuer:\n NATIXIS STRUCTURED ISSUANCE SA"
        r"(?:^|\n)\s*Issuer\s*:\s*\n\s*([A-Z][A-Z\s&',\.\(\)\-]+?)(?:\n)",
        # "ISSUER: BNP PARIBAS..."
        r"ISSUER\s*:\s*([A-Z][A-Z\s&',\.\(\)\-]+?)(?:\n)",
        # "Issuer / Warrant Issuer BNP Paribas..."
        r"Issuer\s*/\s*Warrant\s*Issuer\s+([A-Za-z\s&',\.\(\)\-]+?)(?:\n)",
        # Emetteur francais
        r"Emetteur\s*:\s*([A-Za-z\s&',\.\(\)\-]+?)(?:\n)",
    ]

    for p in patterns:
        m = re.search(p, text)
        if m:
            val = m.group(1).strip()
            val = re.sub(r"\s+", " ", val)
            val = val.rstrip(" ,;:-")
            if 3 < len(val) < 80:
                # Filtrer les faux positifs
                false_pos = ["risk", "on the", "an amount", "Exercise",
                             "at maturity", "but to", "which"]
                if not any(fp.lower() in val.lower() for fp in false_pos):
                    return val

    # Fallback : noms connus (du plus specifique au moins specifique)
    known = [
        "NATIXIS STRUCTURED ISSUANCE SA",
        "BNP Paribas Issuance B.V.", "BNP PARIBAS ISSUANCE B.V.",
        "Credit Suisse International",
        "UBS AG", "BNP Paribas SA", "BNP Paribas",
        "NATIXIS", "Natixis",
        "Goldman Sachs", "Societe Generale", "Barclays",
        "Deutsche Bank", "HSBC", "Leonteq Securities",
        "Julius Baer", "Vontobel", "Morgan Stanley",
    ]
    # Trouver celui qui apparait le plus tot pres d'un label "Issuer"
    best = None
    best_pos = len(text)
    for k in known:
        pos = text.find(k)
        if pos != -1:
            # Bonus si pres d'un label Issuer
            near_issuer = False
            for im in re.finditer(r"(?i)\bIssuer\b", text):
                if abs(pos - im.start()) < 200:
                    near_issuer = True
                    break
            effective_pos = pos - 5000 if near_issuer else pos
            if effective_pos < best_pos:
                best_pos = effective_pos
                best = k
    return best


def extract_maturity(text):
    """Extrait la date de maturite."""
    patterns = [
        # "Maturity Date 11 February 2028" ou "Maturity Date: 16 August 2027"
        r"(?i)(?:Maturity\s+Date|Redemption\s+Date\s*/?\s*Maturity\s+Date)\s*[:.]?\s*(\d{1,2}\s+\w+\s+\d{4})",
        # "Redemption Date / 22 December 2020, being..."
        r"(?i)Redemption\s+Date\s*/\s*(\d{1,2}\s+\w+\s+\d{4})",
        # "Maturity Date: 01/03/2029"
        r"(?i)Maturity\s+Date\s*[:.]?\s*(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4})",
        # "Date de Maturite : 05/06/2030"
        r"(?i)(?:Date\s+de\s+)?Maturit[ey]\s*[:.]?\s*(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4})",
        r"(?i)Echeance\s*[:.]?\s*(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4})",
        # "22 December 2020" after "Maturity Date"
        r"(?i)Maturity\s+Date\s*\n\s*(\d{1,2}\s+\w+\s+\d{4})",
    ]
    for p in patterns:
        m = re.search(p, text)
        if m:
            return m.group(1).strip()

    # Open End
    if re.search(r"(?i)Expiration\s+Date\s*\(?\s*Expiry\s*\)?\s*[:.]?\s*Open\s+End", text):
        return "Open End"

    # Investment Term X years
    m = re.search(r"(?i)Investment\s+Term\s+(?:Up\s+to\s+)?(\d+)\s+years?", text)
    if m:
        return f"Up to {m.group(1)} years"

    return None


def extract_capital_protection(text):
    """Extrait la protection du capital."""
    # "Capital Protection: 90%" / "Capital Protection (at Expiry) None"
    m = re.search(r"(?i)Capital\s+Protection\s*(?:\(at\s+Expiry\))?\s*[:.]?\s*(None|\d{1,3}(?:[.,]\d+)?)\s*%?", text)
    if m:
        val = m.group(1)
        if val.lower() == "none":
            return 0.0
        try:
            return float(val.replace(",", "."))
        except:
            pass

    # "Minimum Redemption 80%"
    m = re.search(r"(?i)Minimum\s+Redemption\s*[:.]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%", text)
    if m:
        return float(m.group(1).replace(",", "."))

    # "Protection du Capital : 90%"
    m = re.search(r"(?i)Protection\s+du\s+Capital\s*[:.]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%", text)
    if m:
        return float(m.group(1).replace(",", "."))

    return None


def extract_worst_or_average(text):
    """Detecte le type de payoff."""
    # WO dans le titre (ex: "su WO AMD")
    if re.search(r"\bWO\b", text):
        return "W"
    if re.search(r"(?i)\b(worst[\s\-]?of|worst[\s\-]?performing|linked\s+to\s+worst|lowest\s+performing)", text):
        return "W"
    if re.search(r"(?i)\b(average|averaging|basket\s+average|performance\s+moyenne)", text):
        return "A"
    return None


def extract_currency(text):
    """Extrait la devise."""
    valid_currencies = ["USD", "EUR", "CHF", "GBP", "JPY", "CAD", "AUD",
                        "SGD", "HKD", "NOK", "SEK", "DKK", "CNY"]
    patterns = [
        r"(?i)(?:Redemption\s+Currency|Specified\s+Currency|Financing\s+Level\s+Currency)\s*[:.]?\s*([A-Z]{3})",
        r"(?i)(?:^|\n)\s*Currency\s*[:.]?\s*([A-Z]{3})",
        r"(?i)Denomination\s*[:.]?\s*([A-Z]{3})",
    ]
    for p in patterns:
        m = re.search(p, text)
        if m:
            val = m.group(1)
            if val in valid_currencies:
                return val
    return None


def detect_bil(text):
    """Detecte si c'est un produit BIL."""
    keywords = [
        "Banque Internationale a Luxembourg",
        "Banque Internationale \u00e0 Luxembourg",
        "www.bil.com",
        "69 Route d'Esch",
        "69, route d'Esch",
        "69 Route d",
        "(BIL)",
    ]
    for kw in keywords:
        if kw in text:
            return True
    # "BIL" seul avec contexte (eviter BILL, BILLION, etc.)
    for m in re.finditer(r"\bBIL\b", text):
        ctx = text[max(0, m.start()-30):m.end()+30]
        if not any(fp in ctx for fp in ["BILL", "BILLION", "BILLING"]):
            return True
    return False


def detect_cln(text):
    """Detecte si c'est un Credit Linked Note."""
    if re.search(r"(?i)\b(credit[\s\-]?linked\s+note|CLN)\b", text):
        return True
    return False


# =============================================================================
# 4. PIPELINE PRINCIPAL
# =============================================================================

def process_pdf(pdf_path):
    """Traite un PDF complet et retourne les resultats."""
    fname = Path(pdf_path).name

    # Extraction du texte brut
    raw_text = extract_text(pdf_path)
    cleaned = clean_text(raw_text)

    # Extraction des ISINs
    all_isins = find_real_isins(raw_text)  # sur le texte brut (pas nettoye)
    pst_isin, underlying_isins = classify_isins(raw_text, all_isins)

    # Extraction des champs
    result = {
        "source_file": fname,
        "text": cleaned,
        "values": {
            "PST_ISIN": pst_isin,
            "BIL": detect_bil(raw_text),
            "CLN": detect_cln(raw_text),
            "CAPITAL_PROTECTION": extract_capital_protection(raw_text),
            "MATURITY": extract_maturity(raw_text),
            "WORST_OR_AVERAGE": extract_worst_or_average(raw_text),
            "CURRENCY": extract_currency(raw_text),
            "ISSUER": extract_issuer(raw_text),
        },
        "underlying_isins": underlying_isins,
    }
    return result


# =============================================================================
# 5. EXPORTS
# =============================================================================

def export_csv(records, output_path, separator=";"):
    """Exporte les resultats en CSV."""
    columns = ["source_file", "PST_ISIN", "BIL", "CLN",
                "CAPITAL_PROTECTION", "MATURITY", "WORST_OR_AVERAGE",
                "CURRENCY", "ISSUER"]
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=columns, delimiter=separator)
        writer.writeheader()
        for r in records:
            row = {"source_file": r["source_file"]}
            row.update(r["values"])
            writer.writerow(row)
    print(f"  CSV exporte : {output_path}")


def export_json(records, output_path):
    """Exporte les resultats en JSON (un objet par PDF avec texte)."""
    data = []
    for r in records:
        data.append({
            "source_file": r["source_file"],
            "text": r["text"],
            "values": r["values"],
            "underlying_isins": r["underlying_isins"],
        })
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, default=str)
    print(f"  JSON exporte : {output_path}")


def export_excel(records, output_path):
    """Exporte les resultats en Excel avec 2 feuilles."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    wb = Workbook()

    # --- Feuille 1 : Resultats principaux ---
    ws1 = wb.active
    ws1.title = "Resultats"

    columns = ["source_file", "PST_ISIN", "BIL", "CLN",
                "CAPITAL_PROTECTION", "MATURITY", "WORST_OR_AVERAGE",
                "CURRENCY", "ISSUER"]

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="4A2D7A", end_color="4A2D7A", fill_type="solid")
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )

    for col_idx, col_name in enumerate(columns, 1):
        cell = ws1.cell(row=1, column=col_idx, value=col_name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border

    for row_idx, r in enumerate(records, 2):
        row_data = {"source_file": r["source_file"]}
        row_data.update(r["values"])
        for col_idx, col_name in enumerate(columns, 1):
            val = row_data.get(col_name, "")
            if val is None:
                val = ""
            cell = ws1.cell(row=row_idx, column=col_idx, value=str(val))
            cell.border = thin_border

    # Largeur des colonnes
    for col_idx, col_name in enumerate(columns, 1):
        ws1.column_dimensions[chr(64 + col_idx)].width = max(len(col_name) + 4, 15)

    # --- Feuille 2 : Underlying ISINs ---
    ws2 = wb.create_sheet("Underlying_ISINs")

    und_columns = ["source_file", "PST_ISIN", "UNDERLYING_ISIN"]
    for col_idx, col_name in enumerate(und_columns, 1):
        cell = ws2.cell(row=1, column=col_idx, value=col_name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border

    row_idx = 2
    for r in records:
        pst = r["values"].get("PST_ISIN", "")
        for uid in r.get("underlying_isins", []):
            ws2.cell(row=row_idx, column=1, value=r["source_file"]).border = thin_border
            ws2.cell(row=row_idx, column=2, value=str(pst or "")).border = thin_border
            ws2.cell(row=row_idx, column=3, value=uid).border = thin_border
            row_idx += 1

    for col_idx in range(1, 4):
        ws2.column_dimensions[chr(64 + col_idx)].width = 25

    wb.save(output_path)
    print(f"  Excel exporte : {output_path}")


def save_converted_texts(records, output_dir):
    """Sauvegarde les textes nettoyes en .txt."""
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    for r in records:
        txt_name = Path(r["source_file"]).stem + ".txt"
        txt_path = Path(output_dir) / txt_name
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(r["text"])
    print(f"  Textes convertis dans : {output_dir}")


# =============================================================================
# 6. EXECUTION
# =============================================================================

# =============================================================================
# 7. SURLIGNAGE PDF
# =============================================================================

def value_to_search_terms(field_name, value):
    """Convertit une valeur extraite en termes a chercher dans le PDF."""
    if value is None:
        return []
    terms = []
    if field_name == "PST_ISIN":
        terms.append(str(value))
    elif field_name == "BIL":
        return ["BIL"] if value is True else []
    elif field_name == "CAPITAL_PROTECTION":
        v = int(value) if isinstance(value, float) and value == int(value) else value
        terms.extend([f"{v}%", f"{v} %", str(v)])
    elif field_name == "MATURITY":
        s = str(value)
        terms.append(s)
        m = re.search(r"(\d{4})", s)
        if m:
            terms.append(m.group(1))
    elif field_name == "WORST_OR_AVERAGE":
        if value == "W":
            terms.extend(["Worst-of", "worst-of", "worst of", "Worst", "WO"])
        elif value == "A":
            terms.extend(["Average", "average", "averaging"])
    elif field_name == "ISSUER":
        terms.append(str(value))
        parts = str(value).split()
        if len(parts) > 1 and len(parts[0]) > 2:
            terms.append(parts[0])
    elif field_name == "CURRENCY":
        terms.append(str(value))
    return terms


def find_words_on_page(page_words, search_text):
    """Cherche un texte dans les mots d'une page PDF."""
    for w in page_words:
        if search_text.lower() in w["text"].strip().lower() and len(search_text) >= 2:
            return [{"x0": float(w["x0"]), "y0": float(w["top"]),
                     "x1": float(w["x1"]), "y1": float(w["bottom"])}]
    search_parts = search_text.lower().split()
    if len(search_parts) < 2:
        return []
    for i in range(len(page_words) - len(search_parts) + 1):
        match = True
        for j, part in enumerate(search_parts):
            wt = page_words[i + j]["text"].strip().lower()
            if part not in wt and wt not in part:
                match = False
                break
        if match:
            matched = page_words[i:i + len(search_parts)]
            return [{"x0": min(float(w["x0"]) for w in matched),
                     "y0": min(float(w["top"]) for w in matched),
                     "x1": max(float(w["x1"]) for w in matched),
                     "y1": max(float(w["bottom"]) for w in matched)}]
    return []


FIELD_COLORS = {
    "PST_ISIN":            (0.2, 0.4, 1.0),
    "ISSUER":              (0.6, 0.2, 0.8),
    "MATURITY":            (0.2, 0.7, 0.3),
    "CAPITAL_PROTECTION":  (1.0, 0.6, 0.0),
    "WORST_OR_AVERAGE":    (0.9, 0.2, 0.2),
    "CURRENCY":            (0.0, 0.6, 0.6),
    "BIL":                 (0.9, 0.8, 0.0),
}


def highlight_pdf(pdf_path, output_path, extracted_values):
    """Cree une copie du PDF avec les champs surlignees."""
    from pypdf import PdfReader, PdfWriter
    from pypdf.annotations import Highlight
    from pypdf.generic import ArrayObject, FloatObject, NameObject, TextStringObject

    try:
        reader = PdfReader(pdf_path)
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)

        count = 0
        with pdfplumber.open(pdf_path) as pdf:
            for page_num, page in enumerate(pdf.pages):
                ph = page.height
                pw_list = page.extract_words()
                if not pw_list:
                    continue
                for field, value in extracted_values.items():
                    if field in ("CLN",):
                        continue
                    terms = value_to_search_terms(field, value)
                    if not terms:
                        continue
                    color = FIELD_COLORS.get(field, (0.5, 0.5, 0.5))
                    found = False
                    for term in terms:
                        positions = find_words_on_page(pw_list, term)
                        if not positions:
                            continue
                        for pos in positions:
                            x0 = pos["x0"] - 1
                            x1 = pos["x1"] + 1
                            y0 = ph - pos["y1"] - 1
                            y1 = ph - pos["y0"] + 1
                            hl = Highlight(
                                rect=(x0, y0, x1, y1),
                                quad_points=ArrayObject([
                                    FloatObject(x0), FloatObject(y1),
                                    FloatObject(x1), FloatObject(y1),
                                    FloatObject(x0), FloatObject(y0),
                                    FloatObject(x1), FloatObject(y0),
                                ]),
                            )
                            hl[NameObject("/C")] = ArrayObject([
                                FloatObject(color[0]),
                                FloatObject(color[1]),
                                FloatObject(color[2]),
                            ])
                            hl[NameObject("/T")] = TextStringObject(field)
                            hl[NameObject("/Contents")] = TextStringObject(
                                f"{field}: {value}"
                            )
                            writer.add_annotation(
                                page_number=page_num, annotation=hl
                            )
                            count += 1
                            found = True
                        if found:
                            break
                    if found:
                        break

        if count > 0:
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "wb") as f:
                writer.write(f)
        return count
    except Exception as e:
        print(f"  ERREUR highlight: {e}")
        return 0




# =============================================================================
# 8. EXECUTION
# =============================================================================

if __name__ == "__main__":
    DATA_DIR = Path("data")
    OUTPUT_DIR = Path("data/output")
    TEXTS_DIR = Path("data/converted_texts")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    pdf_files = sorted(DATA_DIR.glob("*.pdf"))
    print(f"{len(pdf_files)} PDF trouves\n")

    records = []
    for pdf_path in pdf_files:
        print(f"--- {pdf_path.name} ---")
        result = process_pdf(str(pdf_path))
        records.append(result)
        v = result["values"]
        print(f"  PST_ISIN:           {v['PST_ISIN']}")
        print(f"  UNDERLYING_ISINs:   {result['underlying_isins']}")
        print(f"  BIL:                {v['BIL']}")
        print(f"  CLN:                {v['CLN']}")
        print(f"  CAPITAL_PROTECTION: {v['CAPITAL_PROTECTION']}")
        print(f"  MATURITY:           {v['MATURITY']}")
        print(f"  WORST_OR_AVERAGE:   {v['WORST_OR_AVERAGE']}")
        print(f"  CURRENCY:           {v['CURRENCY']}")
        print(f"  ISSUER:             {v['ISSUER']}")
        print()

    print("=== EXPORTS ===")
    export_csv(records, OUTPUT_DIR / "extraction_results.csv")
    export_json(records, OUTPUT_DIR / "extraction_results.json")
    export_excel(records, OUTPUT_DIR / "extraction_results.xlsx")
    save_converted_texts(records, TEXTS_DIR)

    print("\n=== RESUME ===")
    total = len(records)
    for field in ["PST_ISIN", "ISSUER", "MATURITY", "CURRENCY",
                   "CAPITAL_PROTECTION", "WORST_OR_AVERAGE"]:
        filled = sum(1 for r in records if r["values"].get(field) is not None)
        print(f"  {field:22s} : {filled}/{total}")

    print("\n=== SURLIGNAGE PDF ===")
    annotated_dir = OUTPUT_DIR / "annotated"
    for r in records:
        pdf_path = DATA_DIR / r["source_file"]
        out_path = annotated_dir / f"annotated_{r['source_file']}"
        if pdf_path.exists():
            n = highlight_pdf(str(pdf_path), str(out_path), r["values"])
            print(f"  {r['source_file']}: {n} surlignage(s)")
